# 彩票预测项目的科学实现方案

> 项目代号：**LottoLab** —— 彩票数据科学与选号实验室
> 文档角色：高级数据工程师 / 机器学习工程师
> 版本：v1.0 | 日期：2026-09-11
> 核心结论先行：**开奖序列为 i.i.d. 均匀分布，任何策略对"中奖概率"的提升在数学上不可能；本项目的科学价值在于构建"数据平台 + 公平性审计 + 严格回测"的完整工程体系，并利用"合买分奖机制"在条件期望奖金上做唯一合法的优化。**

---

## 1. 项目背景

- 中国福利彩票双色球自 2003-02-23 首期开奖，每周二/四/日 21:15 摇奖，截至当前累计开奖超 3,500 期，全部历史数据公开可采集。
- 单期销量通常在 3~4 亿元量级，公众关注度高，"规律分析""预测软件"类灰色产品泛滥，其中 99% 属于伪科学营销。
- 从工程视角看，彩票数据集是一个**理想的练手数据工程项目**：数据量小（几千行）、结构清晰、真值可验证、理论基线明确（均匀分布）、回测成本极低。
- 本项目定位为**科研/教育型全栈数据项目**：从数据采集、清洗、统计检验、特征工程、模型回测到 API 与可视化，完整复现一条标准数据链路，同时以负结果（negative result）作为一等公民交付物。

## 2. 项目真实目标

不做"预测中奖号码"这种伪目标。目标拆解为五条可验收的子目标：

| 编号 | 目标 | 验收标准 |
|---|---|---|
| G1 | 历史开奖数据资产化（采集→入库→服务） | 双色球全量期次入库，完整率 100%，数据质量分 ≥ 99% |
| G2 | 开奖公平性统计审计 | χ² / Ljung-Box / KS 检验自动出报告，结论可复核 |
| G3 | 智能选号工具（随机 + 约束 + 反热门） | 单次生成 5 注 < 1s，每注附生成原理说明 |
| G4 | 策略回测实验室 | 任意策略 vs 随机基线，输出 Monte Carlo p 值与 ROI 置信区间 |
| G5 | 负结果报告（科普反赌） | 论证"无策略可超越随机"，页面强制展示免责声明 |

**明确排除项**：付费预测服务、代购、资金管理建议、任何"提高中奖概率"的营销话术。

## 3. 彩票预测是否可行的统计学解释

### 3.1 基本模型

摇奖机为物理随机装置，每期开奖相互独立。设第 t 期开奖结果 X_t 在组合空间 C 上服从均匀分布：

- 双色球组合总数 |C| = C(33,6) × 16 = 1,107,568 × 16 = **17,721,088**
- 单注命中一等奖概率 = 1/17,721,088 ≈ 5.65×10⁻⁸

### 3.2 不可预测性的形式化

若 {X_t} 为 i.i.d. 均匀分布，则对任意基于历史信息的（可测）选号策略 f(H_{t-1})：

```
P(f(H_{t-1}) 命中 X_t) = 1/|C| = 1/17,721,088
```

与闭眼随机选号完全相同。证明思路：独立性使得历史 H 与当前 X_t 无关，f(H) 的输出对 X_t 不提供任何信息增益。**推论：冷热号、遗漏追号、走势图、macd 式划线全部无效。**

### 3.3 两个经典谬误

- **赌徒谬误**：某号遗漏 40 期 ≠ "该出了"。每期边际分布不变，遗漏长度服从几何分布，P(遗漏 > n) = (1-p)^n 与"已经遗漏多少期"无关。
- **热手谬误**：近 50 期某号出现 15 次也不代表下期更易出现。频率波动是均匀分布的正常涨落（回归均值）。

### 3.4 多重检验陷阱（本项目必须防的坑）

对 33 个红球分别在多个时间窗做显著性检验，即使数据完全随机，α=0.05 下每 33 个号期望出现约 1.65 个"伪显著"。正确做法：Bonferroni / BH-FDR 校正，并在报告中同时披露检验总数。

### 3.5 各奖级理论概率（回测基线用）

| 奖级 | 规则（红+蓝） | 中奖组合数 | 概率 |
|---|---|---|---|
| 一等奖 | 6+1 | 1 | 1/17,721,088 |
| 二等奖 | 6+0 | 15 | 1/1,181,406 |
| 三等奖 | 5+1 | 162 | 1/109,389 |
| 四等奖 | 5+0 或 4+1 | 7,695 | 1/2,302 |
| 五等奖 | 4+0 或 3+1 | 63,765 | 1/278 |
| 六等奖 | 2+1 / 1+1 / 0+1 | 1,043,640 | ≈1/16.98 |
| 任意中奖 | — | — | ≈ **6.25%** |

红球和值理论分布：均值 102，方差 n(N+1)(N-n)/12 = 6×34×27/12 = 459，σ ≈ 21.4（回测时可做 KS 拟合）。

### 3.6 期望收益与唯一合法"优势"

- 双色球销售额分配约为：奖金 50%、公益金 36%、发行费 14%，即单注 2 元的期望回报 ≈ **-1 元（ROI ≈ -50%）**，与选号策略无关。
- **唯一数学上成立的优化**：一等奖为奖池均分（合买分奖）。中奖概率不可改变，但条件期望奖金 E[奖金 | 中奖] = 奖池份额 / E[同奖注数]。选择"冷门组合"（避开生日号 1–31、吉利数字 6/8/9、等差/同尾等大众模式）可在**不改变中奖概率的前提下提高条件期望奖金**。这是经典彩票数学文献（如 Ziemba 的 Lotto 研究、Haigh 1997 年 JRSS《The statistics of the national lottery》）中反复验证的结论，也是本项目"智能选号"的唯一科学依据。

### 3.7 可行性结论

| 问题 | 结论 |
|---|---|
| 预测下一期号码 | **不可行**，i.i.d. 均匀分布下无信息增益 |
| 验证开奖公平性 | **可行**，χ²/Ljung-Box 审计（若设备有偏，这里能报警——这正是检验的存在价值） |
| 提高中奖概率 | **不可行** |
| 提高条件期望奖金（分奖规避） | **可行**（唯一 edge，量级有限但真实） |
| 量化"任何策略都不灵" | **可行**，回测 + Monte Carlo 显著性检验 |

## 4. 可落地项目定位

产品名：**LottoLab —— 彩票数据科学与选号实验室**（开源、免费、教育向）。

五个功能支柱：

- **P1 数据资产平台**：全量开奖数据 + 奖级明细 + 派生统计，统一 API 服务。
- **P2 公平性审计**：一键生成统计检验报告（χ²、Ljung-Box、KS），对外输出"数据是否随机"的可复核结论。
- **P3 智能选号器**：均匀随机为底座，支持用户约束（和值区间、奇偶比、连号限制、区段均衡），叠加"反热门"冷门度打分（见 3.6）。
- **P4 回测实验室**：内置 6 种策略（随机/冷热/遗漏/马尔可夫/LSTM/XGBoost），walk-forward 回测，输出"全部 ≈ 随机基线"的负结果报告。
- **P5 科普页**：概率计算器（输入注数显示各奖级期望命中）、赌徒谬误演示动画、合规声明。

不做什么：不卖号、不推送购号提醒、不做复购激励、不展示中奖故事、不承诺任何收益。

## 5. 数据来源与字段设计

### 5.1 数据源

| 编号 | 来源 | 方式 | 说明 |
|---|---|---|---|
| S1 | 中国福彩官网开奖公告接口（cwl.gov.cn，findDrawNotice，name=ssq） | HTTP JSON | 主源。需设置 UA，限速 ≤ 1 req/s，接口路径以官网现状为准 |
| S2 | 500 彩票网历史开奖页 | HTML 解析 | 备源，结构与官网交叉校验 |
| S3 | GitHub 公开历史数据集（CSV） | 一次性导入 | 冷启动 bootstrap，仅首次使用 |
| S4 | 管理员手工 CSV 导入 | 后台命令 | 数据缺口兜底 |

采集策略：每日 21:35 与 22:15 两次定时任务（开奖后公告延迟常见），`issue` 幂等 upsert，连续 3 次失败告警。

### 5.2 数据库 DDL（PostgreSQL 15）

```sql
-- 玩种维表
CREATE TABLE dim_lottery (
  lottery_code VARCHAR(8) PRIMARY KEY,      -- 'SSQ' 双色球 / 'DLT' 大乐透
  lottery_name VARCHAR(32) NOT NULL,
  red_min INT NOT NULL, red_max INT NOT NULL, red_count INT NOT NULL,
  blue_min INT NOT NULL, blue_max INT NOT NULL, blue_count INT NOT NULL,
  combo_total BIGINT NOT NULL               -- 17,721,088 / 21,425,712
);
INSERT INTO dim_lottery VALUES
 ('SSQ','双色球',1,33,6,1,16,1,17721088),
 ('DLT','大乐透',1,35,5,1,12,2,21425712);

-- 开奖事实表
CREATE TABLE fact_draw (
  lottery_code VARCHAR(8)  NOT NULL DEFAULT 'SSQ',
  issue        VARCHAR(12) NOT NULL,          -- 期号，如 '2026088'
  draw_date    DATE        NOT NULL,          -- 开奖日（周二/四/日）
  red_1 INT NOT NULL, red_2 INT NOT NULL, red_3 INT NOT NULL,
  red_4 INT NOT NULL, red_5 INT NOT NULL, red_6 INT NOT NULL,  -- 升序存储
  blue   INT NOT NULL,
  sales_amount BIGINT,                        -- 单期销量（元）
  pool_amount  BIGINT,                        -- 奖池余额（元）
  source       VARCHAR(16) NOT NULL,          -- S1/S2/S3/S4
  ingested_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (lottery_code, issue)
);

-- 奖级明细表
CREATE TABLE fact_prize_level (
  lottery_code VARCHAR(8)  NOT NULL,
  issue        VARCHAR(12) NOT NULL,
  level        VARCHAR(4)  NOT NULL,           -- '1'~'6' / 一~九等
  prize_money  NUMERIC(12,2) NOT NULL,         -- 单注奖金（元）
  winner_count INT         NOT NULL,           -- 中奖注数
  PRIMARY KEY (lottery_code, issue, level)
);

-- 单期形态宽表（特征结果落库，供 API/前端直读）
CREATE TABLE fact_draw_stat (
  lottery_code VARCHAR(8) NOT NULL, issue VARCHAR(12) NOT NULL,
  red_sum INT, red_span INT, odd_cnt INT, consec_pairs INT,
  ac_value INT, prime_cnt INT, zone_1_cnt INT, zone_2_cnt INT, zone_3_cnt INT,
  repeat_prev_cnt INT,   -- 与上期重号个数
  tail_repeat_max INT,   -- 同尾号最多出现次数
  PRIMARY KEY (lottery_code, issue)
);

-- 号码遗漏表（逐期快照）
CREATE TABLE fact_omission (
  lottery_code VARCHAR(8) NOT NULL, issue VARCHAR(12) NOT NULL,
  number INT NOT NULL, color CHAR(1) NOT NULL,   -- 'R' 红 / 'B' 蓝
  omission INT NOT NULL,                          -- 截至本期连续未出现期数
  max_omission INT, avg_omission NUMERIC(8,2), last_seen DATE,
  PRIMARY KEY (lottery_code, issue, number, color)
);

-- 回测运行/票据/汇总
CREATE TABLE bt_run (
  run_id BIGSERIAL PRIMARY KEY,
  strategy_code VARCHAR(32) NOT NULL,   -- RANDOM/HOT50/OMISSION/MARKOV/LSTM/XGB/CROWD_AVOID
  params JSONB NOT NULL,                -- 含随机种子，保证可复现
  train_start DATE, train_end DATE, test_start DATE, test_end DATE,
  tickets_per_draw INT DEFAULT 5, budget_per_ticket NUMERIC(8,2) DEFAULT 2.00,
  status VARCHAR(16) DEFAULT 'pending', created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE bt_ticket (
  run_id BIGINT NOT NULL, issue VARCHAR(12) NOT NULL, ticket_no INT NOT NULL,
  red_1 INT, red_2 INT, red_3 INT, red_4 INT, red_5 INT, red_6 INT, blue INT,
  is_won BOOLEAN DEFAULT false, prize_level VARCHAR(4), prize_money NUMERIC(12,2),
  PRIMARY KEY (run_id, issue, ticket_no)
);
CREATE TABLE bt_summary (
  run_id BIGINT PRIMARY KEY,
  draws_covered INT, tickets_total INT,
  total_cost NUMERIC(14,2), total_prize NUMERIC(14,2),
  roi NUMERIC(10,4),                       -- (prize-cost)/cost
  hit_cnt_level1 INT, hit_cnt_level2 INT, hit_cnt_level3 INT,
  hit_cnt_level4 INT, hit_cnt_level5 INT, hit_cnt_level6 INT,
  mc_p_value NUMERIC(8,4)                  -- 对随机基线的 Monte Carlo p 值
);

-- 脏数据隔离区（永不静默丢弃）
CREATE TABLE etl_quarantine (
  id BIGSERIAL PRIMARY KEY, source VARCHAR(16), raw_payload JSONB,
  reason TEXT, quarantined_at TIMESTAMPTZ DEFAULT now()
);
```

数据流：`raw(官网 JSON) → stg(临时表) → fact(清洗后) → stat/omission(特征) → API`。

## 6. 数据清洗规则

| 编号 | 规则 | 违规处理 |
|---|---|---|
| R01 | 期号格式 `^(19\|20)\d{5}$` 且唯一 | 隔离区，reason=ISSUE_FORMAT |
| R02 | 红球为 6 个互异整数 ∈ [1,33]，入库前升序排序；蓝球 ∈ [1,16] | 隔离区，reason=RANGE_INVALID |
| R03 | draw_date ∈ [2003-02-23, 今天] 且为周二/四/日；期号日期与序列连续性校验（允许节假日顺延，缺期需相邻期差 ≤ 7 天） | 隔离区 + 缺期告警 |
| R04 | sales_amount / pool_amount 非空且 > 0；按年度 ±3σ 做离群标记（不删除，仅打标） | 打标 outlier=true |
| R05 | 双源交叉校验：S1 与 S2 同期号码不一致时以官网为准，差异写入 etl_quarantine | 记录 conflict |
| R06 | 奖级一致性：Σ(prize_money × winner_count) ≈ 当期奖池拨付（允许 ±5% 规则误差） | 隔离奖级明细行 |
| R07 | 幂等写入：`ON CONFLICT (lottery_code, issue) DO UPDATE`，重复采集不产生重复行 | — |
| R08 | 迟到数据：开奖当晚 3 次重试（21:35/22:15/23:00），仍未获取则次日晨间任务补采 | 告警 |
| R09 | 时间统一 UTC+8 存储，开奖时刻固定 21:15 | — |
| R10 | 血缘：每行携带 source + ingested_at，可追溯到原始 payload | — |
| R11 | 所有校验失败数据进 etl_quarantine，带 reason，供人工复核 | — |
| R12 | Schema 只增不改（additive evolution），特征表可随时由 fact_draw 全量重算 | — |

核心校验函数（节选）：

```python
import re
from datetime import date

DRAW_WEEKDAYS = {0, 2, 4}          # 周二/四/日（周一=0）
ISSUE_RE = re.compile(r"^(19|20)\d{5}$")

def validate_draw(row: dict) -> list[str]:
    errs = []
    if not ISSUE_RE.match(row["issue"]):
        errs.append("ISSUE_FORMAT")
    reds = [row[f"red_{i}"] for i in range(1, 7)]
    if len(set(reds)) != 6 or not all(1 <= r <= 33 for r in reds):
        errs.append("RANGE_INVALID")
    if not (1 <= row["blue"] <= 16):
        errs.append("RANGE_INVALID")
    d = row["draw_date"]
    if not (date(2003, 2, 23) <= d <= date.today()) or d.weekday() not in DRAW_WEEKDAYS:
        errs.append("DATE_INVALID")
    if row["sales_amount"] is None or row["sales_amount"] <= 0:
        errs.append("SALES_INVALID")
    return errs    # 非空则整行进 etl_quarantine
```

数据质量日报指标：完整率（期数/应开期数）、字段有效率、迟到率、双源一致率、隔离区行数。目标：完整率 100%，有效率 ≥ 99.9%。

## 7. 特征工程清单

> 全部特征**仅用于描述、可视化与异常审计**；逐条标注"预测力预期"，避免团队自欺。

### A. 单期形态特征（每期 1 行，fact_draw_stat）

| 特征 | 定义 | 用途 | 预测力预期 |
|---|---|---|---|
| red_sum | 红球和值（理论均值 102，σ≈21.4） | 分布校验 KS | 无 |
| red_span | max(red)−min(red) | 可视化 | 无 |
| odd_cnt / even_cnt | 奇偶个数（理论 3/3） | 可视化、χ² | 无 |
| consec_pairs | 相邻连号对数 | 可视化 | 无 |
| ac_value | AC 值 = 红球两两差值的不同个数 − (6−1) | 形态统计 | 无 |
| prime_cnt | 质数个数（1,2,3,5,7,...,31 共 11 个质数） | 可视化 | 无 |
| zone_1/2/3_cnt | 区段个数（1–11 / 12–22 / 23–33） | 可视化 | 无 |
| repeat_prev_cnt | 与上一期重号个数（理论期望 6×6/33 ≈ 1.09） | 审计独立性 | 无 |
| tail_repeat_max | 同尾号最多出现次数 | 可视化 | 无 |

### B. 时序统计特征（逐号逐期，fact_omission + 滚动窗）

| 特征 | 定义 | 用途 | 预测力预期 |
|---|---|---|---|
| freq_30 / freq_50 / freq_100 | 近 30/50/100 期出现次数 | 冷热图、Markov/XGB 输入 | 无（均匀分布下为噪声） |
| omission_current | 当前遗漏期数 | 遗漏图 | 无 |
| omission_max / omission_avg | 历史最大/平均遗漏 | 可视化 | 无 |
| hot_cold_score | (freq_50 − 期望) / 标准差 | 规则策略输入 | 无 |

### C. 冷门度特征（选号器专用）

| 特征 | 定义 | 用途 |
|---|---|---|
| crowded_score(组合) | Σ 逐号热度权重：号码 ∈ 1–31（生日区间）+1；含 6/8/9/18/28（吉利号）+1；出现 ≥3 连号 +2；同尾 ≥3 +2；全奇/全偶 +1 | 反热门选号排序 |
| date_pattern_flag | 组合可由纯日期（月/日）构成 | 冷门过滤 |
| split_risk_proxy | 该期历史一等奖注数（合买分奖间接信号） | 条件期望奖金估算 |

### D. ML 标签设计（防泄漏）

- 标签：`y_{t+1,k} = 1 若号码 k 出现在第 t+1 期`（33 个红球各一个二分类标签；蓝球同理 16 个）。
- 特征只允许使用 `≤ t` 期数据；滚动窗口构建，代码评审 checklist 中逐项确认无未来信息。
- 期望表现写入验收标准：AUC ∈ 0.5 ± 0.01，超出即优先排查数据泄漏/标签错误。

## 8. 模型方案对比

| 编号 | 策略 | 原理 | 训练成本 | 预期命中率 vs 随机 | 预期 AUC | 结论 |
|---|---|---|---|---|---|---|
| M0 | RANDOM | 均匀采样组合 | 0 | 基线 | — | **理论最优**，一切对比的锚点 |
| M1 | HOT50 | 近 50 期高频号加权采样 | 极低 | ≈ 基线 | — | 赌徒谬误的工程化演示 |
| M2 | OMISSION | 遗漏值加权采样 | 极低 | ≈ 基线 | — | 谬误演示 |
| M3 | MARKOV | 33 维 0/1 多热序列一阶马尔可夫转移矩阵，按 P(出现\|上期状态) 采样 | 低（<1s） | ≈ 基线 | 0.50 | 负结果 |
| M4 | LSTM | 序列模型，输入多热向量序列，输出 33 个 sigmoid，按概率采样组合 | 中（CPU 数分钟） | ≈ 基线 | 0.50±0.01 | 负结果，主要用于展示"复杂模型≠有效" |
| M5 | XGBOOST | 逐号二分类（freq/omission/形态特征） | 低 | ≈ 基线 | 0.50±0.01 | 负结果，特征重要性全部接近噪声 |
| M6 | CROWD_AVOID | 均匀随机 + 冷门度约束（ rejection sampling 于最低四分位） | 极低 | **= 基线（概率不变）** | — | **唯一保留策略**：条件期望奖金 ↑ |

关键实现约定：

```python
# XGBoost 标签构建（防泄漏示例）
def build_dataset(draws, number, window=50):
    X, y = [], []
    for t in range(window, len(draws) - 1):
        past = draws[:t]                      # 只含 ≤ t 期
        X.append(featurize_number(past, number))   # freq/omission/形态
        y.append(1 if number in draws[t]["reds"] else 0)  # t+1 ... 下一期
    return X, y
```

- 超参起点：XGB `max_depth=4, n_estimators=300, lr=0.05`；LSTM `hidden=64, layers=2, seq_len=50`。
- **异常处理红线**：若任一模型在 ≥500 期回测中以 p<0.01 显著优于随机，第一假设是**实现有 bug（数据泄漏/标签错位）**，第二假设才是设备异常（转公平性审计流程）。禁止直接宣称"发现了规律"。

## 9. 回测框架

### 9.1 设计

- **Walk-forward（滚动起点）**：训练窗 [2003, t) 扩张式，预测 t+1 … t+50，步长 50 期；测试区间为最近 500 期。
- **预算约束**：每策略每期 5 注，单注 2 元，总投入 5,000 元/策略；与真实购彩成本一致。
- **兑奖结算**：票据命中规则用 3.5 节奖级表；单注奖金取该期 fact_prize_level 实际值（缺失时用近 100 期中位数）。
- **随机基线配对**：同测试区间、同注数、随机策略跑 N=200 次 Monte Carlo，构造 ROI 零分布，计算各策略的 `mc_p_value = (1 + rank)/(N + 1)`。
- **可复现性**：bt_run.params 记录随机种子与全部超参；数据快照存 Parquet；同一 run_id 重跑结果必须逐字节一致（回归测试覆盖）。

### 9.2 引擎伪代码

```python
def run_backtest(strategy, test_issues, n_tickets=5, seed=42):
    rng = np.random.default_rng(seed)
    for t in walk_forward(test_issues, step=50):
        ctx = build_context(end=t - 1)            # 特征仅用历史（防泄漏）
        tickets = strategy.pick(ctx, n=n_tickets, rng=rng)
        actual = load_draw(t)
        for tk in tickets:
            level = settle(tk, actual)            # 按奖级规则结算
            record(run_id, t, tk, level, prize_money(level, t))
    return summarize(run_id)                       # ROI、分奖级命中、p 值

null = [run_backtest(RandomStrategy(), test_issues, seed=s) for s in range(200)]
p_value = (1 + rank_of(run.roi, [r.roi for r in null])) / 201
```

### 9.3 输出

- bt_summary 一行 + bt_ticket 全量明细（可下钻到"哪一注、哪一期、中的几等"）。
- 自动生成负结果报告（Markdown）：各策略 ROI 与基线带状对比、p 值表、结论一句话。

## 10. 评估指标

| 类别 | 指标 | 目标/阈值 |
|---|---|---|
| 概率保真 | 各奖级命中率（观测 vs 3.5 节理论值），二项分布 95% CI | CI 覆盖理论值 |
| 收益 | ROI = (总奖金−总成本)/总成本，bootstrap 95% CI | 全策略 CI 覆盖 −50% |
| 显著性 | vs 随机基线的 Monte Carlo p 值；多重策略用 BH 校正 | 无策略 p<0.01（否则查 bug） |
| 判别力 | XGB/LSTM 逐号 AUC | 0.5 ± 0.01 |
| 校准 | 可靠性图（预测概率 vs 实际频率），ECE | ECE < 0.02 |
| 均匀性 | χ²（红 df=32，临界 ≈46.2；蓝 df=15，临界 ≈25.0）、KS | p > 0.05 |
| 序列独立 | Ljung-Box（lag 1–10，对逐号 0/1 序列）、滞后自相关 | p > 0.05 |
| 稳健性 | 分种子、分子时段（每 500 期一段）结论一致性 | 结论不变 |
| 工程 | API p95 延迟；ETL 时长；报告生成时长 | <200ms；<2min；<30s |

## 11. 可视化设计（ECharts）

| 编号 | 图表 | 类型 | 数据绑定 | 交互 |
|---|---|---|---|---|
| C1 | 红球频率热力图 | heatmap，33 列 × 年份行 | fact_omission 聚合 freq | 点击号码联动 C2/C3 |
| C2 | 蓝球频率柱状图 | bar，16 列 | 同上 | 窗口切换 30/50/100/全量 |
| C3 | 遗漏时序 | line × 33（可多选 6 条） | fact_omission | 号码多选、理论均值参考线 |
| C4 | 和值分布 | histogram + 理论正态 N(102, 21.4²) 叠加 | fact_draw_stat | KS 检验 p 值角标 |
| C5 | 奇偶/大小/区段比 | stacked bar 按月 | fact_draw_stat | 时间范围筛选 |
| C6 | AC 值分布 | bar + 理论频次对比 | fact_draw_stat | — |
| C7 | 销量与奖池趋势 | dual-axis line | fact_draw | 缩放、tooltip |
| C8 | 回测累计 ROI 曲线 | line + 200 次随机基线 5–95 分位带 | bt_run/bt_summary | 策略多选对比 |
| C9 | 策略命中率对比 | grouped bar（各奖级观测 vs 理论） | bt_summary | — |
| C10 | 模型 AUC | bar + 0.5 参考线 | bt_summary | — |
| C11 | 概率校准曲线 | diagonal scatter | ML 评估产物 | — |
| C12 | 组合冷门度分布 | heatmap（号码 × 常见组合模式） | 选号器日志 | — |

仪表盘布局：1280 栅格 12 列。首页 = KPI 条（最新期/总期数/总销量/奖池）+ C1 + C7 + C8；分析页 = C2/C3/C4/C5/C6 联动；实验室页 = 运行面板 + C8/C9/C10。暗色主题，色盲安全色板（蓝/橙主色）。

## 12. 后端/API 设计

**技术栈**：Python 3.11、FastAPI、Pydantic v2、SQLAlchemy 2.0、PostgreSQL 15（开发可用 SQLite）、APScheduler、Typer（ETL CLI）、structlog、Docker Compose。

```
lottolab-backend/
├── app/
│   ├── api/v1/routes/        # draws.py, stats.py, numbers.py, pick.py, backtest.py, models.py
│   ├── core/                 # config, logging, scheduler
│   ├── services/             # etl, cleaning, features, stats_tests, picker, backtest, ml
│   ├── repositories/         # SQLAlchemy 查询封装
│   └── models/               # ORM + Pydantic schema
├── etl/                      # 采集/清洗/特征 CLI（typer）
├── tests/                    # pytest：单元 + 回归（种子一致性）+ API 契约
└── docker-compose.yml        # api + postgres + scheduler
```

| 方法 | 路径 | 说明 | 关键参数/响应 |
|---|---|---|---|
| GET | /api/v1/draws | 开奖列表（倒序分页） | `lottery, page, size` |
| GET | /api/v1/draws/{issue} | 单期详情含奖级明细 | — |
| GET | /api/v1/stats/summary | 最新期 + KPI + 最近形态 | — |
| GET | /api/v1/numbers/frequency | 频率统计 | `color=R/B, window` |
| GET | /api/v1/numbers/omission | 当前遗漏 | `color` |
| GET | /api/v1/stats/tests | χ²/Ljung-Box/KS 审计结果 | — |
| POST | /api/v1/pick | 智能选号 | `strategy, count, constraints` |
| GET | /api/v1/backtest/runs | 回测运行列表 | 分页 |
| POST | /api/v1/backtest/runs | 创建回测（后台任务） | strategy, 区间, 注数 |
| GET | /api/v1/backtest/runs/{run_id} | 汇总 + 明细下钻 | — |
| GET | /api/v1/models | 模型指标（AUC/ECE） | — |
| GET | /api/v1/health | 健康检查 | — |

响应示例：

```json
// POST /api/v1/pick  {"strategy":"CROWD_AVOID","count":2,
//                     "constraints":{"red_sum":[90,114],"odd_cnt":[2,4]}}
{
  "tickets": [
    {"reds": [3, 12, 19, 24, 27, 33], "blue": 5,
     "crowded_score": 2, "note": "避开生日区间与吉利号；理论中奖概率与随机完全一致"}
  ],
  "disclaimer": "彩票开奖为独立随机事件，本工具不改变中奖概率。请理性购彩，未满18周岁禁止购彩。"
}
```

NFR：读接口 p95 < 200ms（Redis 可选缓存频率类查询）；写接口仅限回测创建（后台队列）；限流 60 req/min；CORS 白名单；OpenAPI 自动文档 `/docs`。

## 13. 前端页面设计

**技术栈**：React 18 + Vite + TypeScript + ECharts + Tailwind CSS；状态用 TanStack Query（服务端状态）+ Zustand（本 UI 态）。

| 路由 | 页面 | 内容 |
|---|---|---|
| `/` | 数据总览 | 最新开奖卡片、KPI 条、C1 热力图、C7 趋势、C8 入口 |
| `/analysis` | 走势分析 | C2/C3/C4/C5/C6 多图联动，号码/窗口筛选 |
| `/tools` | 智能选号 | 策略选择（纯随机/约束随机/反热门）、约束表单、结果卡（含原理与免责声明） |
| `/lab` | 回测实验室 | 新建回导向（策略→区间→预算）、ROI 基线带图、策略对比表、明细下钻 |
| `/models` | 模型对比 | AUC 柱状、校准曲线、特征重要性 |
| `/about` | 科普与合规 | 概率计算器、谬误演示、完整免责声明 |

首页线框（示意）：

```
┌──────────────────────────────────────────────┐
│ LottoLab   总览 | 走势 | 选号 | 实验室 | 关于 │
├──────────┬──────────┬──────────┬─────────────┤
│ 最新期    │ 累计期数  │ 累计销量  │ 奖池余额     │
│ 2026088  │ 3,587    │ 1.2万亿  │ 21.3亿      │
├──────────┴──────────┴──────────┴─────────────┤
│ 红球频率热力图（33 × 年份）      [C1]          │
├──────────────────────┬───────────────────────┤
│ 销量/奖池趋势 [C7]    │ 回测 ROI vs 随机带 [C8] │
├──────────────────────┴───────────────────────┤
│ ⚠ 免责声明：开奖为随机事件，本站不预测不保证收益 │
└──────────────────────────────────────────────┘
```

交互规范：所有数据图空态/加载态/错误态三态齐全；移动端 768 断点降级为单列；选号结果页强制首屏展示免责声明块。

## 14. 风险与合规说明

- **未成年人**：全站页脚固定"未满 18 周岁禁止购彩"；不做青少年向营销。
- **反诱导设计**：不推送购号提醒、不做签到/复购激励、不展示中奖故事、售号类文案一律禁止。免责声明模板（直接可用）：

  > 本平台为数据科学与教育项目。彩票每期开奖为相互独立的随机事件，任何方法均无法预测开奖结果或提高中奖概率，本平台的选号工具亦不例外。历史数据分析仅用于统计描述与公平性审计。彩票期望回报为负（约 -50%），请理性对待，量力而行，切勿沉迷。未满 18 周岁禁止购彩。

- **数据合规**：仅采集官方公开开奖公告做统计分析；遵守来源站点条款与限速；注明数据来源；不转售、不二次分发原始数据；个人信息最小化（无账号体系，不采集用户数据）。
- **模型风险**：过拟合与多重检验误读（见 3.4）；任何"显著优于随机"的回测结果先按 bug 处理；负结果如实公开。
- **表述红线**：对外文案禁用"预测""提高中奖率""内部数据""必中"等词；项目开源且免费，禁止商业化包装为付费预测服务。
- **安全**：API 只读为主、参数白名单校验、依赖漏洞扫描（pip-audit + npm audit）进 CI。
- **运营红线 checklist**（发版前逐项打勾）：☐ 免责声明全站可见 ☐ 无购彩入口/外链 ☐ 无未成年人向内容 ☐ 数据来源标注 ☐ 负结果报告随版发布。

## 15. 7 天开发计划

| Day | 里程碑 | 任务 | 交付物 | 验收标准 |
|---|---|---|---|---|
| D1 | M1 骨架+数据 | 仓库脚手架、DDL 落库、S1/S3 采集器、幂等 upsert | `etl ingest` 可跑通，全量期次入库 | fact_draw ≥ 3,500 行，重跑零重复 |
| D2 | M2 质量 | 清洗规则 R01–R12、隔离区、DQ 日报、双源校验 | `etl clean --report` | 有效率 ≥ 99.9%，冲突有日志 |
| D3 | M3 特征+审计 | fact_draw_stat / fact_omission 生成；χ²、Ljung-Box、KS 检验服务化 | `etl features` + `stats/tests` API | 统计检验输出与手工核算一致 |
| D4 | M4 回测核心 | 回测引擎、兑奖结算、随机基线 Monte Carlo、M0/M1/M2/M6 四策略 | `POST /backtest/runs` 可用 | 种子一致性回归测试通过 |
| D5 | M5 模型 | M3 Markov、M4 LSTM、M5 XGB 训练脚本 + 评估（AUC/ECE/校准） | `ml/train.py` + 指标落库 | AUC ∈ 0.5±0.01，超限自动告警 |
| D6 | M6 全栈 | FastAPI 全部端点、React 五页面、ECharts 12 图、免责声明组件 | docker-compose 一键起 | API 契约测试 100% 过，页面可演示 |
| D7 | M7 发布 | 部署、负结果报告生成、README、演示脚本、红线 checklist | v1.0 tag + 在线演示 | checklist 全勾，演示 10 分钟走完 G1–G5 |

节奏保障：每晚跑一次端到端冒烟（ingest→clean→features→backtest→report）；每里程碑打 tag；D4/D5 各预留 20% 缓冲吸收数据源异常。

## 16. 项目亮点总结

1. **科学诚实**：把"负结果"作为正式交付物——用 χ²、Ljung-Box、Monte Carlo p 值严格论证"无策略超越随机"，直接反赌反诈，工程界稀缺的严谨性展示。
2. **全链路完整度**：采集→清洗（含隔离区与血缘）→特征→统计审计→模型→回测→API→可视化，一套可复用的数据工程模板，换数据源即可迁移到任意领域。
3. **回测方法论**：walk-forward + 预算约束 + 200 次随机基线零分布 + 多重检验校正 + 种子级可复现（回归测试），这套框架本身就是可移植的量化评估资产。
4. **唯一真实 edge 的工程化**：冷门度打分 + rejection sampling 实现合买分奖规避，"概率不变、条件期望奖金提升"，有文献支撑、有可实现路径。
5. **反脆弱设计**：任何模型显著跑赢随机先按 bug 排查的"红线机制"，从流程上杜绝自欺与翻车。
6. **合规即产品**：免责声明、反诱导、未成年人保护内嵌到页面与 API 响应，而非事后贴补丁。
7. **面试/作品集价值**：一个项目同时覆盖数据工程、统计学、机器学习评估、全栈开发与合规意识，且体量 7 天可控。

---

### 附录 A：快速启动

```bash
git clone https://github.com/<org>/lottolab.git && cd lottolab
docker compose up -d                    # postgres + api + scheduler
etl ingest --source S1                  # 全量采集
etl clean && etl features && etl stats-tests
python -m services.backtest --strategy ALL --tickets 5 --seed 42
open http://localhost:5173              # 前端
```

### 附录 B：参考方向（经典彩票数学文献）

- Haigh, J. (1997). *The Statistics of the National Lottery*. JRSS Series A —— 奖池分奖与组合热门度的经典分析。
- Ziemba, W. T. 等 Lotto 系列研究 —— 冷门组合的条件期望奖金优化。
- Henze, N. (1997). *A statistical and combinatorial approach to the lottery* —— 均匀性检验方法。

> 本文档所有概率均按组合数学精确计算；实施前请以彩票官方现行规则核对奖级与奖金结构。

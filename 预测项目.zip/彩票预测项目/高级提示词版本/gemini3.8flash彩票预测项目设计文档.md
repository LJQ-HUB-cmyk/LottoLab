# 彩票系统科学工程方案与数据验证平台 (Scientific Lottery Analysis & Backtesting Framework)

**项目代号**：Project StochasticInsight  
**版本**：v1.0.0  
**定位**：基于高阶随机过程、贝叶斯推断与深度学习的可重现统计检验与博弈优化平台  
**编写人**：高级数据架构师 / 资深机器学习工程师  

---

## 1. 项目背景

彩票（以中国福利彩票双色球、超级大乐透或海外Powerball/Mega Millions为代表）属于离散有限样本空间上的无放回多重抽样博弈。长期以来，公众对彩票存在严重的“均值回归误区”（如赌徒谬误、热手效应）。市场上充斥着伪科学的“走势图专家”与黑产预测软件。

本项目旨在从现代工业级机器学习与数据工程视角，建立标准化的历史中奖数据湖，利用数理统计（假设检验、随机性检验、马尔可夫性检验）与高维非线性特征挖掘算法，构建一个严肃的科学评估、概率建模、对抗下注策略回测平台，验证现代机器学习算法在严格伪随机/伪无偏物理抽样场景下的拟合上限与博弈边界。

---

## 2. 项目真实目标

1. **破除认知伪科学**：通过严格假设检验（NIST SP 800-22全套套件、游程检验、自相关函数ACF分析），以量化数据证伪常见民间策略（奇偶配比法、连号追尾法、冷热号追注法）。
2. **构建高吞吐概率流水线**：搭建高可用历史开奖数据爬取、清洗、校验与特征计算的自动化ETL/ELT数据管道。
3. **探索微弱统计偏差（Weak Signal Extraction）**：在极低信噪比（SNR $\approx$ 0）场景下，验证物理摇奖机微小机械磨损、重力差异或开奖环境温湿度是否在多变量空间产生弱统计漂移（Statistical Drift）。
4. **正期望值（+EV）奖池博弈优化**：当浮动累积奖池滚存至极高阈值且存在特定返奖规则时，结合组合数学、覆盖设计（Covering Designs）与群体心理偏好建模（避开公众高频选择的生日号等），在不改变单注中奖概率的前提下，**最小化头奖分摊概率（Split Rate Reduction）**，最大化单注期望收益。

---

## 3. 彩票预测是否可行的统计学解释

### 3.1 概率空间与独立同分布假设 (i.i.d.)
以双色球（6/33红球 + 1/16蓝球）为例：
- 红球样本空间大小为 $\binom{33}{6} = 1,107,568$
- 蓝球样本空间大小为 $16$
- 全局状态空间大小为 $\Omega = \binom{33}{6} \times 16 = 17,721,088$
- 理想物理抽球机模型满足：任意期抽样向量 $X_t \sim \text{Uniform}(\Omega)$，且 $X_t \perp X_{t-k} \ (\forall k \ge 1)$。

### 3.2 统计学定理约束
1. **大数定律 (LLN)**：随着期数 $N \to \infty$，各号码出现的相对频率必依概率收敛于理论概率 $p = \frac{6}{33}$，但局部有限截断期内并不存在拉回机制（无记忆性）。
2. **马尔可夫无记忆性**：条件概率分布满足：
   $$P(X_t = s \mid X_{t-1}, X_{t-2}, \dots, X_1) = P(X_t = s) = \frac{1}{|\Omega|}$$
3. **有效市场假说（EMH）的弱式对偶**：所有历史开奖号码序列已充分反映并被摇球后完全重置，任何仅基于历史价格/历史号码的时间序列模型（ARIMA、LSTM、Transformer）均无法战胜蒙特卡洛随机采样基线。

### 3.3 科学预测的边界定义
- **不可行域**：试图单点命中下一期高阶奖项（头奖/二等奖）的精确组合，数学期望完全由排列组合决定，任何模型命中率在置信区间内与随机采样无统计显著差异（$p > 0.05$）。
- **可行域（弱优化）**：
  1. 检验物理摇球机制是否存在非随机缺陷（卡方拟合优度检验、KS检验）。
  2. 根据公众选号心理（偏好对角线、生日号1~31、等差数列），利用自然语言处理/社交媒体挖掘逆向选择冷门组合，防止头奖撞车。

---

## 4. 可落地项目定位

本系统定位为：**高阶随机事件探索与策略回测引擎（Stochastic Analytics & Covering Engine）**。

| 模块 | 核心功能 | 价值交付 |
| :--- | :--- | :--- |
| **Randomness Audit** | NIST随机性测试矩阵、熵值监测 | 输出物理抽样公平性与机械漂移学术报告 |
| **Hypothesis Testing** | 常见走势图策略实证证伪 | 揭示“专家选号法”回测下的破产概率 |
| **Combinatorial Covering** | 轮盘矩阵（Wheel System）、Steiner三元系 | 最小注数覆盖保证保底奖级（如中6保5） |
| **Expected Value Engine** | 奖池ROI与赔率敏感性分析 | 输出何时下注正期望（EV > 1.0）策略信号 |

---

## 5. 数据来源与字段设计

### 5.1 数据源拓扑
- **源A（官方直连）**：中国体彩网 / 福彩网 Open API 或历史结果静态HTML归档。
- **源B（公信校验源）**：新浪彩票、500万彩票网镜像历史爬取（三源互相校验哈希一致性）。

### 5.2 关系型Schema设计 (PostgreSQL 16)

```sql
-- 1. 彩种元数据表
CREATE TABLE lottery_types (
    id VARCHAR(32) PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    pool_rules JSONB NOT NULL, -- 奖池递进规则、抽奖区间定义
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. 原始期次数据表
CREATE TABLE lottery_draws (
    draw_id VARCHAR(64) PRIMARY KEY, -- e.g., SSQ_2024001
    lottery_type_id VARCHAR(32) REFERENCES lottery_types(id),
    period_number INT NOT NULL,
    draw_date DATE NOT NULL,
    sales_amount NUMERIC(15, 2), -- 全国销售金额（元）
    pool_amount NUMERIC(15, 2),  -- 当前奖池累积金额（元）
    red_balls INT[] NOT NULL,     -- 有序数组存储，例如 [3, 11, 14, 20, 25, 31]
    blue_balls INT[] NOT NULL,    -- [12]
    draw_order INT[] NOT NULL,    -- 出球原始顺序（检验物理机时序依赖关键）
    checksum CHAR(64) NOT NULL,   -- SHA256防篡改校验
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. 奖项与派奖明细
CREATE TABLE lottery_prizes (
    id BIGSERIAL PRIMARY KEY,
    draw_id VARCHAR(64) REFERENCES lottery_draws(draw_id),
    prize_level INT NOT NULL,     -- 1等奖, 2等奖...
    win_count INT NOT NULL,
    prize_amount NUMERIC(15, 2) NOT NULL
);

-- 索引
CREATE INDEX idx_draws_type_date ON lottery_draws(lottery_type_id, draw_date DESC);
CREATE INDEX idx_draws_period ON lottery_draws(lottery_type_id, period_number);
```

---

## 6. 数据清洗规则

1. **时序无空洞校验**：遍历 `period_number` 序列，断言连续性 $\Delta = 1$。遇到年份交替（跨年跨度）使用日历对照表处理长假停售期（如春节休市）。
2. **取值空间硬断言**：
   - 双色球红球：长度必为6，去重后长度必为6，$\forall x \in \text{red_balls}, 1 \le x \le 33$。
   - 双色球蓝球：长度必为1，$1 \le y \le 16$。
3. **出球顺序完整性**：`draw_order` 集合必须等于 `red_balls` 集合，且保留原始时间戳/抓取时间序列。
4. **多源交叉审计**：三方源爬取结果进行字段级比对，若产生 Diff，触发警报并置于 `draws_quarantine` 隔离区进行人工审查。
5. **金额类型格式化**：过滤文本中的“元”、“亿”字符，统一转化为精确高精度 `NUMERIC(15,2)`，防浮点精度失真。

---

## 7. 特征工程清单

虽然全局满足随机分布，但在特征工程中构建以下六大类共计 48 个衍生指标，用于作为统计检验模型与深度学习拟合的输入向量：

| 类别 | 特征名 | 计算逻辑 | 维度 |
| :--- | :--- | :--- | :--- |
| **基础统计量** | `sum_val` | $\sum_{i=1}^6 x_i$（红球和值） | 1 |
| | `ac_val` | 复杂度指数（所有两两差值去重数减去 $k-1$） | 1 |
| | `span_val` | 极差 $\max(X) - \min(X)$ | 1 |
| | `odd_even_ratio` | 奇数个数 / 偶数个数 | 1 |
| | `prime_composite_ratio`| 质数个数 / 合数个数 | 1 |
| | `zone_ratio_3` | 区间分布比（1-11, 12-22, 23-33） | 3 |
| **形态学特征** | `consecutive_count` | 相邻连续号码对数（如11,12为1对） | 1 |
| | `tail_same_count` | 同尾数（尾数 mod 10）碰撞度 | 1 |
| **时序记忆特征** | `omission_lag_k` | 各号码自上次开出以来的遗漏期数（Omission Count） | 33 |
| | `freq_window_N` | 过去 $N \in \{10, 30, 50, 100\}$ 期的出现滚动频率 | $33 \times 4$ |
| | `transition_prob` | 基于前一期号码的一阶马尔可夫转移期望值 | 1 |
| **物理环境代理** | `seasonality_sin/cos` | 开奖日期在年周期（365天）中的正弦/余弦嵌入 | 2 |
| | `draw_day_of_week` | 开奖星期（周二、周四、周日）One-Hot | 3 |
| **信息熵与混沌** | `shannon_entropy` | 基于当前期号码分布计算的信息熵 | 1 |
| | `hurst_exponent` | 基于和值历史序列计算的赫斯特指数（滑动窗口200） | 1 |

---

## 8. 模型方案对比

本项目构建4种模型族谱，旨在从不同技术路径探测规律，并将其与纯蒙特卡洛纯随机选号作双盲对照。

```
                    ┌─────────────────────────┐
                    │    Baseline: 纯蒙特卡洛   │
                    └───────────┬─────────────┘
                                │ 对照
  ┌─────────────────────────────┼─────────────────────────────┐
  ▼                             ▼                             ▼
【方案A】统计物理与贝叶斯推断   【方案B】GBDT/Tabular 机器学习  【方案C】时序深度学习/Attention
- Dirichlet-Multinomial       - LightGBM / XGBoost 多标签    - Time-Series Transformer
- 空间泊松点过程              - Focal Loss 处理极端不平衡    - 双向LSTM + 自注意力网络
- 优势: 可解释极强, 绝不过拟合- 优势: 挖掘高阶特征交叉交叉   - 优势: 捕获超长潜在滑动依赖
- 劣势: 拟合上限受分布假设限制- 劣势: 极易在白噪声中过拟合   - 劣势: 计算量大，参数坍缩
```

### 综合决策评估矩阵

| 评估维度 | 蒙特卡洛随机基线 | 方案A：Bayesian-Dirichlet | 方案B：LightGBM + FocalLoss | 方案C：Transformer Seq2Seq |
| :--- | :--- | :--- | :--- | :--- |
| **过拟合抗性** | 完美（无参数） | 极高（共轭先验正则化） | 差（需极度激进的Early Stop）| 极差（几乎必然拟合噪声） |
| **可解释性** | 显而易见 | 输出精确后验概率密度与置信区间 | SHAP/Gain值特征贡献分析 | 注意力热力图权重分析 |
| **推断延迟** | < 0.1ms | < 2ms | < 10ms | > 50ms |
| **落地定位** | 对照组标尺 | 检验设备微观倾向度首选方案 | 挖掘复杂手工衍生特征组合 | 学术证伪实验对照 |

**结论**：生产环境推荐采用 **方案A作为主概率密度校准器**，结合 **组合轮盘算法（Wheel Design）** 进行投注覆盖生成。方案B与C部署于离线沙盒，作为反向证伪算法库。

---

## 9. 回测框架

遵循量化金融标准，杜绝任何形式的**前视偏差（Look-ahead Bias）**与**数据泄漏（Data Leakage）**。

### 9.1 严格的时间序列滚动交叉验证 (Rolling Walk-Forward Validation)

```
[===== 训练集 (Period 1 ~ 1500) =====] -> [验证集: 1501 ~ 1600] -> [测试推断: 1601]
       [===== 训练集 (Period 101 ~ 1600) =====] -> [验证集: 1601 ~ 1700] -> [测试推断: 1701]
```
- **绝对隔离**：计算第 $T$ 期任何特征（如遗漏值、滑动窗口均值）时，严格仅使用 $[1, T-1]$ 的全量数据。
- **动态更新**：每向前推进一期，数据管道执行增量注入，特征矩阵实时重建。

### 9.2 资金与头寸管理引擎
- **初始模拟资本**：$C_0 = 1,000,000.00$ 元（人民币）。
- **下注费率**：单注固定 2.00 元。
- **奖金兑付**：严格按照开奖历史中的实际派奖金额（真实一、二等奖动态奖金）计算结算，计入税费（超过1万元征收20%偶然所得税）。
- **止损逻辑**：Kelly公式变体约束下的单期最大暴露度（Max Drawdown Cap）。

---

## 10. 评估指标体系

严禁使用纯准确率（Accuracy），必须使用贴合概率预测与极度不平衡分类的指标集：

### 10.1 概率与分布拟合指标
1. **多分类对数损失 (Multi-class Log-Loss / NLL)**：
   $$\text{LogLoss} = -\frac{1}{N} \sum_{i=1}^N \sum_{j=1}^{33} y_{i,j} \log(p_{i,j})$$
   与均匀分布 $p = \frac{6}{33} \approx 0.1818$ 计算所得的理论基线 LogLoss 比较。若模型LogLoss未低于基线，证明模型无信息增益。
2. **Brier Score**：评估概率校准度的均方误差指标。
3. **卡方统计量 $p$-value**：对模型预测输出与真实开奖结果执行独立性皮尔逊检验，判断差异是否具备统计学显著性（$\alpha = 0.05$）。

### 10.2 投资回报与效用指标
1. **ROI (投资回报率)**：
   $$\text{ROI} = \frac{\sum \text{奖金收益} - \sum \text{投注成本}}{\sum \text{投注成本}} \times 100\%$$
2. **最大回撤 (Max Drawdown, MDD)**：资产曲线从峰值回落的最大幅度。
3. **破产概率 (Risk of Ruin)**：蒙特卡洛模拟10万次下的资本归零概率。
4. **覆盖利用率 (Covering Efficiency)**：使用轮盘矩阵（如中6保5）相对于随机下注的单组注数缩减倍率。

---

## 11. 可视化设计

前端/报表需提供直观且严谨的科学可视化仪表盘：

1. **NIST随机性雷达图**：展示频数、块频数、游程、DFT谱分析、长连续1等15项指标的 $p$-value分布（低于0.01标记为红色警告区域）。
2. **号码热力衰减矩阵 (Omission Decay Heatmap)**：X轴为近100期，Y轴为1~33号，色阶表示遗漏深度与开出脉冲。
3. **资金净值曲线 vs 纯随机对冲曲线**：双对数坐标轴，展示模型策略净值与随机下注净值的衰减对齐走势（展示庄家优势抽水带来的固定斜率下倾）。
4. **组合轮盘覆盖度拓扑图**：通过有向无环图（DAG）展示大复式过滤至精简注的修剪路径。

---

## 12. 后端与 API 设计

### 12.1 技术栈选型
- **语言/运行时**：Python 3.11 + FastAPI (异步高吞吐)
- **数值与模型运算**：NumPy, SciPy, Polars (高性能数据清洗), PyTorch / LightGBM
- **任务队列**：Celery + Redis（处理长时回测与蒙特卡洛模拟）
- **数据库**：PostgreSQL 16

### 12.2 核心 RESTful API 契约

#### 1. 获取随机性检验审计报告
- **Endpoint**: `GET /api/v1/audit/randomness`
- **Params**: `lottery_type=ssq&start_period=2020001&end_period=2024050`
- **Response**:
```json
{
  "code": 200,
  "data": {
    "sample_size": 650,
    "chi_square_uniformity": {
      "statistic": 31.45,
      "p_value": 0.493,
      "is_random": true
    },
    "runs_test": {
      "z_score": -0.42,
      "p_value": 0.674
    },
    "verdict": "PERFECTLY_RANDOM_NO_EXPLOITABLE_BIAS"
  }
}
```

#### 2. 触发策略回测任务
- **Endpoint**: `POST /api/v1/backtest/run`
- **Body**:
```json
{
  "strategy_name": "Bayesian_Dirichlet_Covering",
  "lottery_type": "ssq",
  "start_period": 2021001,
  "end_period": 2024001,
  "initial_capital": 500000.0,
  "wheel_filter_rules": {
    "sum_range": [80, 140],
    "max_consecutive": 2,
    "ac_min": 6
  }
}
```
- **Response**: `{"code": 202, "task_id": "c62b3fd8-d218-45eb-9e7f-68212fc10f2c"}`

#### 3. 获取回测明细
- **Endpoint**: `GET /api/v1/backtest/result/{task_id}`
- **Response**:
```json
{
  "code": 200,
  "data": {
    "status": "COMPLETED",
    "metrics": {
      "total_invested": 312000.0,
      "total_returned": 146640.0,
      "roi": -0.53,
      "max_drawdown": 0.58,
      "jackpot_hit_count": 0,
      "tier3_hit_count": 4
    },
    "random_baseline_roi": -0.52
  }
}
```

---

## 13. 前端页面设计

采用 **Vue 3 + TypeScript + Tailwind CSS + ECharts 5** 构建：

1. **Dashboard (全局态势驾驶舱)**：
   - 顶部统计卡片：收录期数、最后数据抓取延迟、当前奖池金额、NIST通过率（100%）。
   - 主屏：历史开奖与最新一期多模型预测概率分布（条形柱状图）。
2. **Strategy Lab (策略试验台)**：
   - 侧边栏：多维度参数滑块（和值上下限、奇偶配比过滤、连续号限制、连冷过滤）。
   - 核心区：交互式轮盘设计器（选择红球大底池12个号码，一键生成“中6保5”的缩水注数清单）。
3. **Backtest Benchmark (量化回测看板)**：
   - 净值曲线走势图（多策略对比：定投随机、马尔可夫、贝叶斯过滤）。
   - 回撤与每月明细收益热力表。
4. **Science Center (科学反赌专题页)**：
   - 交互式模拟器：让用户自选一组号码，模拟1秒钟执行10万次摇奖，直观展示用户资产归零的指数曲线。

---

## 14. 风险与合规说明

1. **反博彩免责声明**：系统首页及API输出头部必须硬编码警示语：“彩票为国家公益事业，其物理出球符合严格离散均匀分布，不存在任何确定性预测算法。本系统仅用于教学研究与数理统计分析。”
2. **禁止生产环境投注闭环**：严禁接入任何第三方自动代购、自动化打票设备，系统内部不提供任何投注资金充值端口，彻底杜绝合规与黑灰产风险。
3. **安全与脱敏**：敏感环境变量（数据库密码、爬虫代理节点）使用Vault管理，日志输出禁止携带任何个人信息。

---

## 15. 7天敏捷工程落地计划

```
Day 1: 数据流搭建与Schema初始化
├── 搭建 PostgreSQL 16 数据库与 Redis 7
├── 编写爬虫模块（官方源 + 双镜像源）抓取近20年全量数据
└── 编写数据一致性断言脚本，通过 Checksum 固化历史数据湖

Day 2: 统计检验工具库 (Statistical Core) 开发
├── 封装 scipy.stats 实现卡方均匀性、自相关ACF、单双比检验
├── 集成 NIST SP 800-22 随机性检验轻量套件
└── 输出第一版全量历史数据随机性白皮书报告

Day 3: 特征工程与组合数学引擎
├── Polars 编写 48 项特征生成器（遗漏、和值、AC值、连号）
├── 实现旋转矩阵（Wheel System）数学缩水算法（中6保5、中6保4）
└── 编写严格无前视偏差的滚动数据生成器

Day 4: 建模与基准对比构建
├── 搭建蒙特卡洛纯随机基线引擎
├── 实现贝叶斯-狄利克雷概率校准模型
├── 接入 LightGBM 多标签分类模型并计算 LogLoss
└── 对比三者与真实出球的统计差异并固化结果

Day 5: 真实历史回测引擎 (Backtest System)
├── 实现带有真实历史浮动派奖计算的结算流水线
├── 注入税费机制、单期下注风控与资金净值追踪
└── Celery 异步长任务调度打通

Day 6: 后端 API 与前端交互集成
├── FastAPI 编写 6 个核心 REST 路由，集成 Pydantic V2 校验
├── Vue 3 + Tailwind 搭建策略配置与回测结果交互看板
└── 绘制 ECharts 资产回撤图与随机性雷达图

Day 7: 系统联调、压力测试与交付
├── 撰写 pytest 自动化测试套件（覆盖率 > 85%）
├── 产出 Docker-Compose 一键部署包
└── 输出《彩票随机性实证检验与系统用户手册》
```

---

## 16. 项目亮点总结

1. **绝对严谨的学术与工业定性**：区别于市面上的欺骗性“预测预测神器”，本项目直接以数理统计与严格假设检验为立足点，将破除赌徒谬误与科学反赌作为系统核心输出。
2. **高保真无泄漏回测架构**：采用滚动时间窗口（Walk-Forward），完全模拟真实时序推进，杜绝一切由于全局归一化带来的未来信息污染。
3. **运筹与组合优化赋能**：将传统单点预测转移到“组合覆盖设计（Covering Designs）”与“逆公众心理避撞”的博弈论正道，提供具有工程应用价值的注数压缩矩阵。
4. **开箱即用的现代化全栈架构**：PostgreSQL 严格类型约束 + Polars 向量化特征计算 + FastAPI 异步非阻塞 + Docker 容器化编排，具备极高的扩展性与复用价值。

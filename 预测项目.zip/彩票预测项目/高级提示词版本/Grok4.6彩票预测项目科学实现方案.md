# 彩票预测项目科学实现方案

**工程设计文档 · Lottery Analytics Workbench (LAW) · 彩研台**

| 项 | 内容 |
| --- | --- |
| 文档编号 | LAW-DS-2026-001 |
| 版本 | V1.0（可开发冻结稿） |
| 日期 | 2026-09-11 |
| 角色 | 高级数据工程师 / 机器学习工程师 |
| 主玩法 | 中国福利彩票双色球（SSQ），大乐透（DLT）为第二数据源 |
| 仓库名 | `lottery-analytics-workbench` |
| 密级 | 工程内部。禁止对外宣传“可预测中奖” |

---

## 0. 一页结论（先读这个再写代码）

1. **不能把“预测下期开奖号码并实现正期望收益”写成项目成功标准。** 在开奖过程可视为独立均匀随机的前提下，任何基于历史的模型，对单注组合的命中概率都等于 `1 / |Ω|`。双色球 `|Ω| = C(33,6)×C(16,1) = 17,721,088`，一等奖概率 `≈ 5.643e-8`。
2. **可以做成一个可上线、可答辩、可复现的量化研究系统。** 成功标准改为：数据可信、检验可审计、特征无泄漏、回测无偷看、模型打不过随机要能证明、策略在官方派奖表下的 ROI 可计算。
3. **7 天交付物不是“神机”，是 LAW：开奖数仓 + 统计检验台 + 特征/模型实验台 + 走步回测器 + 合规前端。** 对外文案只允许“历史统计分析 / 策略回测 / 随机性检验”，禁止“杀号包中 / 稳赚 / AI 预测下期”。
4. **机器学习在本项目里的正确用法：** 把“选 6 个红球”建成逐号排序问题，用 walk-forward 把它和均匀随机、频率法放在同一张表里比。预期结果：Hit@6 贴近 `1.091`，Brier 贴近常数 `p=6/33`。若某模型稳定高出 0.15 以上，先查泄漏，再查开奖器偏差，最后才谈“有效信号”。
5. **唯一接近“工程优化”而不是“玄学预测”的模块：** 在预算约束下做组合覆盖（covering），最大化指定奖级的命中概率。这是组合优化，不是对随机源的预测。

---

## 1. 项目背景

### 1.1 业务事实

- 双色球：红球 33 选 6，蓝球 16 选 1，单注 2 元。开奖日通常为周二、周四、周日 21:15。
- 大乐透：前区 35 选 5，后区 12 选 2，单注 2 元。
- 历史公开数据完整、结构化、可爬可核。这使它成为**罕见的长序列离散随机实验场**，不是一个可套利市场。
- 市面“预测产品”的通病：用全历史拟合、用当期特征、用命中个数当准确率、不扣成本、不报置信区间、把过拟合当玄学。

### 1.2 为什么值得做工程

对数据/ML 团队，这个题目的训练价值高于彩票本身：

| 能力 | 在本项目中的具体体现 |
| --- | --- |
| 无泄漏时序建模 | 只能用 t-1 及以前预测 t |
| 稀有事件 | 一等奖在全样本中期望次数 ≈ 期数 / 1772 万，不能当分类标签 |
| 正确的零模型 | 均匀随机 + 超几何分布，不是 “50% 准确率” |
| 科学沟通 | 把负结论做成产品，而不是藏起来 |
| 数据质量 | 双源对账、期号连续性、开奖号码集合约束 |
| 合规产品化 | 免责声明、功能开关、审计日志 |

### 1.3 不做的事

- 不承诺下期号码。
- 不接支付、不代购、不返佣。
- 不采集用户身份与购彩记录。
- 不以“准确率 95%”等不可复现指标对外展示。

---

## 2. 项目真实目标

### 2.1 目标分层（必须写进 README 和验收单）

**P0 系统目标（7 天必须完成）**

1. 入库双色球历史 ≥ 2500 期，字段级对账通过。
2. 对红球/蓝球做 χ² 拟合优度、游程、自相关，输出 p 值与滚动窗口图。
3. 特征表 `feat_ssq_draw_v1` 按期物化，时间泄漏测试 100% 通过。
4. 三个模型并跑：Uniform / FreqTop6 / LightGBMRank。
5. Walk-forward 回测器输出 Hit@6、奖级分布、ROI、相对零模型的 z 分数。
6. FastAPI + 前端 7 个页面可演示，每页有合规声明。

**P1 研究目标（有时间再做）**

- 大乐透同一套管线复用。
- 覆盖设计（covering）模块：给定 N 注，最大化五等奖理论概率。
- LSTM / 共现图模型作为对照，不进入默认前端。

**P2 明确非目标**

- 提高用户中奖期望使之转正。
- 自动跟单、推送“今夜必出”。
- 用生成式模型直接输出 6 个红球当作答案。

### 2.2 量化成功标准

| 指标 | 达标线 | 失败怎么处理 |
| --- | --- | --- |
| 双源期号一致率 | ≥ 99.9% | 低于则冻结模型训练 |
| 号码集合约束违反 | 0 | 流水线失败 |
| 泄漏测试 | 0 条特征使用当期开奖 | CI 红灯 |
| Uniform Hit@6 | 落在理论 95% 区间 | 回测器实现错误 |
| Freq / LGBM vs Uniform | 报告 Δ 与 p 值，不设“必须赢” | 这就是结果 |
| API 有 `disclaimer` 字段 | 100% | 缺则禁止上线 |
| 单期预测接口耗时 | p95 < 300 ms（预计算） | 改为离线物化 |

### 2.3 用户是谁

1. **自己 / 数据团队**：答辩、作品集、方法论演示。
2. **对随机性感兴趣的分析者**：看检验与回测，不看“推荐号”。
3. **不是购彩决策用户。** 产品信息架构按这个假设设计。

---

## 3. 彩票预测是否可行的统计学解释

本章是整个项目的理论基础，代码里的 `null_model.py` 必须与这里一致。

### 3.1 样本空间

双色球一次开奖是无放回均匀抽样：

```
红球：从 {1..33} 抽 6 个无序集合
蓝球：从 {1..16} 抽 1 个
|Ω| = C(33,6) × 16 = 1,107,568 × 16 = 17,721,088
P(一等奖) = 1 / 17,721,088 ≈ 5.643 × 10^{-8}
```

大乐透：

```
|Ω_DLT| = C(35,5) × C(12,2) = 324,632 × 66 = 21,425,712
```

### 3.2 核心定理（工程表述）

设开奖序列 `D_t` 在 `Ω` 上 **i.i.d. Uniform**。任意可测规则 `f`，只用 `D_1..D_{t-1}` 与公开协变量（销量、奖池、日历）生成票 `τ_t`：

```
P(τ_t = D_t | D_1..D_{t-1}, X_t) = P(τ_t = D_t) = 1/|Ω|
```

推论：

- 历史频率、冷热号、遗漏值、神经网络、LLM，只要开奖器无偏，都不能改变单注命中率。
- “准确率”若定义为猜中一等奖，则全历史期望命中次数 `T / 17721088`。T=3000 时期望 0.00017 次。这个标签不能训练。
- 可训练的标签只能是**号码级或奖级级的弱事件**（某红球是否出现，出现个数），其基线已由超几何分布给出。

### 3.3 红球命中个数的零模型（必须实现）

模型每期给出 6 个红球预测，真实开奖 6 个红球。命中个数：

```
X ~ Hypergeometric(N=33, K=6, n=6)
P(X=k) = C(6,k) · C(27,6-k) / C(33,6)   k=0..6
E[X] = 6 × 6 / 33 = 1.090909
Var(X) = n·(K/N)·(1-K/N)·(N-n)/(N-1)
       = 6 · (6/33) · (27/33) · 27/32
       ≈ 0.7531
SD(X) ≈ 0.8678
```

数值表（回测报告必须打印，禁止四舍五入乱写）：

| k | P(X=k) | 约 1 期/几次 |
| --- | --- | --- |
| 0 | 0.3496 | 2.86 |
| 1 | 0.4434 | 2.26 |
| 2 | 0.1803 | 5.55 |
| 3 | 0.0253 | 39.5 |
| 4 | 0.00125 | 800 |
| 5 | 1.85e-5 | 5.4 万 |
| 6 | 5.43e-7 | 184 万（仅红球全中，还不含蓝球） |

任何模型的 Hit@6 均值必须和 `1.091` 比，并画 95% 带：`1.091 ± 1.96 · 0.868 / sqrt(T_test)`。T_test=500 时半宽 ≈ 0.076。均值 1.20 才刚接近“值得去查泄漏/偏差”，不是“可商用预测”。

### 3.4 单号频率检验

号码 i 在 T 期内出现次数 `N_i ~ Binomial(T, p)`，`p = 6/33`（红）或 `1/16`（蓝）。号码之间同期内负相关（无放回），χ² 仍可用：

```
E = T · 6 / 33
χ² = Σ_i (N_i - E)² / E     df = 32
```

T=3000 时 E≈545.45。功效：相对偏差 8%（真实 p=0.196 vs 0.182）时，渐近功效很高。**这是质检开奖器，不是选号。**

蓝球：`p=1/16`，df=15，T=3000 时 E=187.5。

### 3.5 冷热号为什么看起来“有用”

遗漏值 L_i 是几何分布等待时间。人们在 L_i 大时买入，是赌徒谬误。无偏时：

```
P(下期出现 | 已遗漏 k 期) = 6/33
```

与 k 无关。回测模块 `strategy.cold` 与 `strategy.hot` 必须给出与 Uniform 无显著差异的结果，作为回归测试：若冷号策略显著优于随机，优先怀疑实现把“当期遗漏”算成了“含当期”。

### 3.6 期望收益

设票价 C=2。派奖为离散分布 G（官方奖级）。无偏时：

```
EV = E[G] - C < 0
```

中国电脑彩票返奖率法定上限相关规则下，长期返奖大约五成量级，EV 约为 -0.8 到 -1.2 元/注（随奖池浮动）。**模型若不能证明开奖非均匀，就不能声称 EV 改善。** 回测 ROI 的正确公式：

```
ROI = (Σ 派奖 - Σ 成本) / Σ 成本
```

展示必须同时给成本、派奖、最大回撤。禁止只报“命中期数”。

### 3.7 什么情况下预测“暂时可行”

只有这些，且都要写成告警而不是功能：

1. **开奖器有偏**（χ² 长期拒绝 H0，且偏差在样本外稳定）。此时最优策略是最大似然组合，不是神经网络。
2. **数据错误**（官方录入、爬虫错位）被模型学到。这是 bug。
3. **奖级结构与覆盖设计**：不预测哪组会出，只在预算内最大化某奖级概率。EV 仍为负，只是方差形状不同。
4. **信息泄漏**（用了当期销量完值、开奖后再统计的遗漏）。这是作弊。

### 3.8 给模型的标签为什么不能是“是否一等奖”

T=3000，正样本期望 0.00017。任何以 jackpot 为 label 的分类器，最优预测是全 0。必须使用：

- 号码级：`y[i] = 1{i ∈ red_set}`，33 个伯努利（不独立）。
- 排序级：每期 33 行，6 个正样本，LambdaRank。
- 奖级级：把票与开奖比出的奖级当回报，做策略评估，不做直接分类。

---

## 4. 可落地项目定位

### 4.1 一句话

**彩研台 LAW：双色球/大乐透公开开奖的可复现研究工作台，用统计检验与走步回测证明“历史不能预测下期”，并提供覆盖优化与可视化，而不是售号。**

### 4.2 产品边界

| 模块 | 做 | 不做 |
| --- | --- | --- |
| 数据 | 双源抓取、对账、版本化 | 用户票根识别 |
| 统计 | χ²、ACF、游程、分布拟合 | 风水、生肖、试机号因果解释 |
| 模型 | 排序模型 + 零模型对照 | 输出“今晚必出 03 12 17”无区间 |
| 回测 | 官方派奖表 + 成本 | 忽略成本的命中率排行榜 |
| 覆盖 | 给定预算的组合优化 | 包装成“复式稳中”销售 |
| 前端 | 研究台、方法论文档 | 支付、直播荐号、社群跟单 |

### 4.3 技术栈（按 7 天可完工锁定，禁止再换）

```
语言：Python 3.11
API：FastAPI + Pydantic v2 + Uvicorn
DB：PostgreSQL 16
ORM：SQLAlchemy 2.0 + Alembic
计算：pandas 2.x, numpy, scipy, scikit-learn, lightgbm
任务：先同步；超 60s 的训练走后台 Job 表
前端：Vite + React + TypeScript + Tailwind + TanStack Query + Recharts
容器：docker-compose（api / web / postgres）
测试：pytest + httpx；前端不强制 E2E（7 天）
```

### 4.4 仓库目录（Day 1 一次性建好）

```
lottery-analytics-workbench/
  README.md
  pyproject.toml
  docker-compose.yml
  Makefile
  configs/
    ssq.yaml
    dlt.yaml
    prizes_ssq.yaml
  alembic/
  src/law/
    __init__.py
    config.py
    db/
      models.py
      session.py
    ingest/
      base.py
      ssq_500.py
      ssq_cwl.py
      reconcile.py
    clean/
      rules.py
      qa.py
    features/
      registry.py
      ssq_draw.py
      leak_check.py
    stats/
      goodness_of_fit.py
      hypergeometric.py
      acf_runs.py
    models/
      base.py
      uniform.py
      frequency.py
      lgbm_rank.py
      train.py
    backtest/
      walker.py
      prizes.py
      strategies.py
      report.py
    covering/
      greedy.py
    api/
      main.py
      schemas.py
      routers/
        draws.py
        stats.py
        models.py
        backtests.py
        research_ticket.py
  frontend/
  tests/
    test_invariants.py
    test_leak.py
    test_hypergeom.py
    test_backtest_null.py
    test_prizes.py
  data/
    raw/ .gitkeep
    processed/ .gitkeep
  jobs/
```

### 4.5 配置冻结（`configs/ssq.yaml`）

```yaml
lottery: SSQ
red: { n: 33, k: 6 }
blue: { n: 16, k: 1 }
price_yuan: 2
draw_weekdays: [1, 3, 6]   # 周二=1 若以周一=0 则改为 [1,3,6] 并在代码里单测
timezone: Asia/Shanghai
min_issue: "03001"
features:
  version: feat_ssq_draw_v1
  windows: [10, 30, 50, 100]
model:
  id: lgbm_rank_v1
  min_train_draws: 800
  valid_draws: 200
  walk_step: 1
backtest:
  start_issue: "10001"
  tickets_per_draw: 1
  capital_yuan: 10000
```

---

## 5. 数据来源与字段设计

### 5.1 数据源（按优先级）

| 优先级 | 源 | 用途 | 接口形态 | 风险 |
| --- | --- | --- | --- | --- |
| A | 500.com 走势历史 | 主抓取 | HTML table `history.php?start=&end=` | 页面改版 |
| B | 中国福彩 cwl.gov.cn 开奖公告 | 权威对账 | 站点公告/JSON（按实际响应适配） | 反爬、结构不稳 |
| C | 手工官方公告抽样 | 黄金集 50 期 | CSV 入库 | 人工 |
| D | 体彩官网（DLT） | 第二玩法 | 同类适配器 | 字段不同 |

实现要求：每个源一个 adapter，统一吐 `RawDraw`。禁止在 adapter 里做特征。

`RawDraw`：

```python
class RawDraw(BaseModel):
    lottery: Literal["SSQ", "DLT"]
    issue: str                 # 标准化后 5 位或当年期号，见清洗
    draw_date: date
    red: list[int]             # 未排序也可，清洗阶段排序去重
    blue: list[int]
    sales_yuan: Decimal | None
    pool_yuan: Decimal | None
    prize_breakdown: dict | None
    source: str
    source_url: str
    raw_payload: str           # 原始 HTML/JSON 文本
    raw_hash: str              # sha256(raw_payload)
    fetched_at: datetime
```

### 5.2 抓取规则

- User-Agent 固定项目名 + 联系邮箱；QPS ≤ 0.5；失败指数退避 1/2/4/8s，最多 5 次。
- 按期号窗口抓，默认 `start=min(db.max_issue-5, min_issue)` 做重叠抓取，便于发现事后修正。
- 原始 `raw_payload` 落盘 `data/raw/{source}/{issue}.txt`，库内只存 hash + 路径。
- 禁止无校验全量覆盖：只 upsert 哈希变化的期。

### 5.3 关系模型（PostgreSQL）

```sql
CREATE TABLE lottery (
  code TEXT PRIMARY KEY,          -- SSQ / DLT
  name TEXT NOT NULL,
  red_n INT NOT NULL,
  red_k INT NOT NULL,
  blue_n INT NOT NULL,
  blue_k INT NOT NULL,
  price_cents INT NOT NULL
);

INSERT INTO lottery VALUES
('SSQ', '双色球', 33, 6, 16, 1, 200),
('DLT', '大乐透', 35, 5, 12, 2, 200);

CREATE TABLE draw (
  id BIGSERIAL PRIMARY KEY,
  lottery_code TEXT NOT NULL REFERENCES lottery(code),
  issue TEXT NOT NULL,
  draw_date DATE NOT NULL,
  red SMALLINT[] NOT NULL,
  blue SMALLINT[] NOT NULL,
  sales_yuan NUMERIC(18,2),
  pool_yuan NUMERIC(18,2),
  prize_json JSONB
);

CREATE UNIQUE INDEX ux_draw_lottery_issue ON draw (lottery_code, issue);
CREATE INDEX ix_draw_date ON draw (lottery_code, draw_date);

CREATE TABLE draw_ball (
  draw_id BIGINT NOT NULL REFERENCES draw(id) ON DELETE CASCADE,
  pool TEXT NOT NULL CHECK (pool IN ('red','blue')),
  num SMALLINT NOT NULL,
  PRIMARY KEY (draw_id, pool, num)
);

CREATE TABLE draw_source (
  id BIGSERIAL PRIMARY KEY,
  lottery_code TEXT NOT NULL,
  issue TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT,
  raw_path TEXT,
  raw_hash TEXT NOT NULL,
  parsed JSONB NOT NULL,
  fetched_at TIMESTAMPTZ NOT NULL,
  UNIQUE (lottery_code, issue, source)
);

CREATE TABLE reconcile_issue (
  id BIGSERIAL PRIMARY KEY,
  lottery_code TEXT NOT NULL,
  issue TEXT NOT NULL,
  status TEXT NOT NULL,  -- MATCH / MISMATCH / SINGLE_SOURCE
  detail JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE feat_ssq_draw_v1 (
  issue TEXT PRIMARY KEY,
  asof_issue TEXT NOT NULL,     -- 必须等于上一期，泄漏检查用
  draw_date DATE NOT NULL,
  feats JSONB NOT NULL,
  feat_hash TEXT NOT NULL,
  built_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE model_run (
  id UUID PRIMARY KEY,
  model_id TEXT NOT NULL,
  feature_version TEXT NOT NULL,
  train_end_issue TEXT NOT NULL,
  params JSONB NOT NULL,
  metrics JSONB NOT NULL,
  artifact_path TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE prediction (
  model_run_id UUID REFERENCES model_run(id),
  issue TEXT NOT NULL,          -- 被预测的期，训练不得包含此期
  lottery_code TEXT NOT NULL,
  red_scores DOUBLE PRECISION[33] NOT NULL,  -- index 0 = 号码1
  blue_scores DOUBLE PRECISION[16] NOT NULL,
  top_red SMALLINT[6] NOT NULL,
  top_blue SMALLINT[1] NOT NULL,
  disclaimer TEXT NOT NULL,
  PRIMARY KEY (model_run_id, issue)
);

CREATE TABLE backtest_run (
  id UUID PRIMARY KEY,
  model_id TEXT NOT NULL,
  strategy_id TEXT NOT NULL,
  start_issue TEXT NOT NULL,
  end_issue TEXT NOT NULL,
  tickets_per_draw INT NOT NULL,
  metrics JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE audit_log (
  id BIGSERIAL PRIMARY KEY,
  at TIMESTAMPTZ DEFAULT now(),
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  payload JSONB
);
```

`red` 数组约束（用触发器或写入时 Python 断言，7 天内 Python 侧强制即可）：

- `len(red)==6`，`len(set(red))==6`，`1 <= x <= 33`，写入前 `sorted`。
- 蓝球同理。
- `issue` SSQ 标准化为 5 位数字字符串（`03001`…`26091`）。年份 2003 起。

### 5.4 `prize_json` 结构

```json
{
  "stake_yuan": 2,
  "levels": [
    {"level": 1, "name": "一等奖", "need_red": 6, "need_blue": 1, "winners": 8, "per_stake_yuan": 5000000, "floating": true},
    {"level": 2, "name": "二等奖", "need_red": 6, "need_blue": 0, "winners": 120, "per_stake_yuan": 180000, "floating": true},
    {"level": 3, "name": "三等奖", "need_red": 5, "need_blue": 1, "winners": 1400, "per_stake_yuan": 3000, "floating": false},
    {"level": 4, "name": "四等奖", "need_red": 4, "need_blue": 1, "winners": 0, "per_stake_yuan": 200, "floating": false},
    {"level": 5, "name": "五等奖", "need_red": 4, "need_blue": 0, "winners": 0, "per_stake_yuan": 10, "floating": false},
    {"level": 6, "name": "六等奖", "need_red": 0, "need_blue": 1, "winners": 0, "per_stake_yuan": 5, "floating": false}
  ]
}
```

固定奖级派奖规则在 `configs/prizes_ssq.yaml` 写死（三至六等奖；四/五等奖含多种球面组合）。浮动奖回测默认用**该期实际 per_stake**，缺失则用中位数填充并打标 `prize_imputed=true`。

四等奖判定：`(red_hits, blue_hits) in {(5,0),(4,1)}`。五等奖：`{(4,0),(3,1)}`。六等奖：`{(2,1),(1,1),(0,1)}`。必须单测 18 种 `(hits_r, hits_b)` 映射，禁止在前端重写这张表。

---

## 6. 数据清洗规则

全部放 `src/law/clean/rules.py`，每条规则有 `rule_id`，失败写 `qa_result`。默认策略：**硬失败不入库**，不静默修正号码。

### 6.1 期号

| rule_id | 规则 | 动作 |
| --- | --- | --- |
| ISS-01 | 去空格，禁止非数字 | REJECT |
| ISS-02 | 长度 5，或 `YYYYNNN` 则转 5 位（20YY + 期序需对照日历表） | 能唯一定位则标准化，否则 REJECT |
| ISS-03 | 期号在 `(lottery_code)` 内唯一 | REJECT 重复（除非 hash 相同则 skip） |
| ISS-04 | 期号序列允许空洞（停售），但空洞写入 `draw_gap` 表 | WARN |
| ISS-05 | `draw_date` 必须落在该期所属星期规则 ± 1 天（节假日） | WARN，不 REJECT |

### 6.2 号码

| rule_id | 规则 | 动作 |
| --- | --- | --- |
| BAL-01 | 红 6 蓝 1（SSQ） | REJECT |
| BAL-02 | 全部 int，无前导零问题（`08`→8） | CAST |
| BAL-03 | 红 ∈[1,33]，蓝 ∈[1,16] | REJECT |
| BAL-04 | 红无重复，蓝无重复 | REJECT |
| BAL-05 | 入库排序升序 | TRANSFORM |
| BAL-06 | 禁止 `red` 与蓝球比较越界等串列 | REJECT |

### 6.3 金额

| rule_id | 规则 | 动作 |
| --- | --- | --- |
| AMT-01 | 销量、奖池 ≥ 0 | REJECT if <0 |
| AMT-02 | 销量对滚动 90 期中位数的 z 分数，绝对值大于 8 | WARN，保留 |
| AMT-03 | 销量缺失允许，特征侧用 `sales_missing=1` | PASS |
| AMT-04 | 币种人民币，单位元，两位小数 | CAST |

### 6.4 对账

```
对同一 (lottery, issue)：
  若 A、B 都有：
    red/blue 全等 → MATCH
    否则 MISMATCH，draw 表不更新，等待人工
  若只有 A：
    SINGLE_SOURCE，允许进入 draw，标记 source_count=1
黄金集 C：与 draw 冲突 → 以 C 为准，并开 ISSUE 工单
```

### 6.5 时间与时区

- `draw_date` 用上海日历日。
- `fetched_at` 存 UTC。
- 特征 `asof` 以**期号顺序**为准，不以抓取时间为准。禁止用 `now()` 参与特征。

### 6.6 QA 闸门（每次 ingest 结束必跑）

```python
assert (df.red.map(len) == 6).all()
assert df.apply(lambda r: sorted(r.red) == r.red, axis=1).all()
assert df.duplicated(["lottery_code","issue"]).sum() == 0
assert set(itertools.chain.from_iterable(df.red)).issubset(range(1,34))
```

`tests/test_invariants.py` 复制这些断言，用 20 期夹具。

### 6.7 修正与回溯

官方若更正某期（极罕见）：

1. 新 payload 新 hash → `draw_source` 追加一行。
2. `draw` 更新号码。
3. `feat_ssq_draw_v1` 从该期起全部作废重算。
4. 受影响 `model_run` 标记 `stale=true`，不自动覆盖生产展示，需手动重跑回测。

---

## 7. 特征工程清单

### 7.1 泄漏铁律

特征行 `issue = t` 只能使用 `draw.issue < t` 的开奖，以及 t 期**开奖前已知**的日历变量。

允许：星期、是否节假日、距离上次开奖天数、t 期开奖前已公布的奖池（若拿不到则不用）。

禁止：t 期开奖号码、t 期开奖后销量、包含 t 的滚动统计、用未来做标准化。

`leak_check.py`：

```python
# 伪代码
for col in feature_columns:
    assert feature_asof[col].issue < target_issue
# 置换测试：打乱当期号码，历史特征不变
# 若模型验证分跟着变，说明特征混入当期
```

CI 必须包含：把训练集标签 shuffle，LGBM 的 valid NDCG 掉到随机水平附近。

### 7.2 特征版本

只维护一个生产版本 `feat_ssq_draw_v1`。新列只能加 `v2`，禁止改 v1 含义。

物化粒度：一期一行。33 个红球的编号特征放进 `feats` JSON，键稳定有序。

### 7.3 描述性（可进报表，默认不进模型）

这些是开奖的确定性函数，用于可视化，**不要再当作独立预测信号重复输入**（多重共线）：

| 名 | 定义 |
| --- | --- |
| sum_red | 六红之和，理论范围 21–168，均匀抽样期望 102 |
| span | max-min |
| odd_cnt | 奇数个数 |
| big_cnt | ≥17 的个数 |
| zone3 | 1-11 / 12-22 / 23-33 各几个 |
| consec_pairs | 相邻自然数对个数，如 8,9 |
| ac_value | AC 值（号码复杂度，按行业公式实现并单测） |
| prime_cnt | 质数个数（质数表写死） |

### 7.4 生产特征（进 LGBM）

对每个红球号码 i=1..33、窗口 W∈{10,30,50,100}：

| 特征名 | 定义 | 说明 |
| --- | --- | --- |
| `freq_{i}_{W}` | 过去 W 期 i 出现次数 / W | 主频率 |
| `freq_{i}_{W}_z` | (freq - p) / sqrt(p(1-p)/W), p=6/33 | 标准化 |
| `recency_{i}` | 距上次出现的期数，从未出现则 W_max+1 | 冷号 |
| `recency_{i}_exp` | exp(-recency/20) | 衰减热度 |
| `repeat_last_{i}` | 上期是否出现 | 重号 |
| `neighbor_last_{i}` | 上期出现 i-1 或 i+1 | 邻号神话对照 |
| `cooc_pmi_{i}_{W}` | 与上期每个开出号的 PMI 均值 | 共现 |
| `dow_sin` `dow_cos` | 开奖星期循环编码 | 日历 |
| `issue_idx` | 从最小期起的序号 / 1000 | 缓慢时间 |
| `gap_days` | 距上期日历天数 | 节假日 |

蓝球 i=1..16 同样做 `bfreq_*`、`brecency_*`。

全局（每期一个，广播到 33 行）：

| 特征名 | 定义 |
| --- | --- |
| `sales_z_90` | 上期销量相对 90 期 z，缺失=0 且 `sales_isna=1` |
| `pool_log` | log1p(上期奖池) |
| `entropy_red_50` | 近 50 期经验分布熵 |

### 7.5 排序学习行格式（真正喂给模型的表）

不要 一期一个多标签向量 作为 LightGBM 主方案。用：

```
一行 = (issue_t, number_i)
label = 1 if i in red_t else 0
group = issue_t
特征 = 上述以 i 为下标的列 + 全局列
每期 33 行，6 个正样本
```

蓝球单独一张表，每期 16 行、1 个正样本。

### 7.6 不要做的特征

- 生肖、五行、阴阳、彩民论坛词频（7 天范围外，且不可复现）。
- 试机号当因果特征（无机制，可放附录实验，不进 v1）。
- 把 `sum_red` 未来值、开奖后再计算的遗漏写进 t。
- 对全历史做 MinMax 再切训练/验证（标准化泄漏）。滚动窗口统计必须在窗口内完成。

### 7.7 特征清单冻结文件

`src/law/features/registry.py` 内 `FEATURES_V1: list[str]` 作为唯一列清单。训练、推理、泄漏检查、API schema 都 import 它。禁止散落字符串。

---

## 8. 模型方案对比

### 8.1 问题定义

```
输入：issue t 的特征（仅历史）
输出：红球 33 维分数 s_i，蓝球 16 维分数
票：红取 s 最大的 6 个，蓝取最大 1 个（策略层可改为采样）
禁止：直接生成离散组合再对 1700 万类做 softmax
```

### 8.2 方案表

| ID | 名称 | 机制 | 训练 | 推理 | 预期 Hit@6 | 7天 | 定位 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| M0 | Uniform | 均匀随机或固定种子抽样 | 无 | 随机 6+1 | 1.091 | 必做 | 零模型 |
| M1 | FreqTop6 | 近 W=100 频次最高 6 红 + 蓝最高 | 无 | 排序 | ≈1.09 | 必做 | 热号神话 |
| M2 | ColdTop6 | 遗漏最大 6 红 | 无 | 排序 | ≈1.09 | 必做 | 冷号神话 |
| M3 | LGBMRank | LightGBM LambdaRank | 2–5 min | <10 ms | 1.09–1.16 | 必做 | 主 ML |
| M4 | LGBMBinary | 同一行表，objective=binary，按 p 排序 | 2–5 min | <10 ms | 与 M3 接近 | 备选 | 校准更好 |
| M5 | Logit | sklearn 逻辑回归 + number one-hot | 秒级 | 快 | ≈1.09 | 选做 | 可解释基线 |
| M6 | LSTM | 输入 (30,33) 二元矩阵 | 易过拟合 | 慢 | 不可优于 M3 除非泄漏 | 不做默认 | 研究 |
| M7 | GNN/共现 | 号码图 | 重 | 重 | 同随机 | 不做 | 研究 |

### 8.3 主模型 M3 规格

```python
# train 集构造
# 只取 issue < train_end
params = dict(
    objective="lambdarank",
    metric="ndcg",
    eval_at=[6],
    learning_rate=0.03,
    num_leaves=31,
    min_data_in_leaf=40,
    feature_fraction=0.8,
    bagging_fraction=0.8,
    bagging_freq=1,
    lambda_l2=1.0,
    verbose=-1,
)
# n_estimators=800, early_stopping=50 on 最近 valid_draws 期
# 约束：min_data_in_leaf 不得 < 40，防止背期号
```

训练脚本伪代码：

```python
def walk_train(draws, cfg):
    issues = [d.issue for d in draws]
    for t in issues[cfg.min_train_draws:]:
        train_iss = [i for i in issues if i < t][-cfg.min_train_draws:]
        # 禁止 valid 与 test 重叠
        X, y, g = build_rank_table(train_iss)  # labels 来自各期开奖，特征 asof < 该期
        booster = lgb.train(...)
        pred = booster.predict(build_X_for_issue(t))  # 33 scores
        yield t, pred
```

默认产品不每期重训。7 天采用：**固定切分** `train: 最早 ~ 倒数第 500 期之前`，`test: 最后 500 期` 只走一步；另加 **expanding walk，step=20 期** 降低计算（约 25 次训练）。报告两种，walk 作为主结论。

### 8.4 为什么不用深度模型当主模型

样本有效独立单位是“期”，不是球。3000 期对 LSTM 很小。33 维稀疏二元序列的可学自相关，在 H0 下应为 0。深度模型的唯一现实风险是**更容易把泄漏学满**。若做 LSTM：必须同一套 walk-forward，禁止 shuffle。

### 8.5 推理输出合同

```json
{
  "lottery": "SSQ",
  "target_issue": "2026091",
  "model_id": "lgbm_rank_v1",
  "train_end_issue": "2026088",
  "red": [{"num": 7, "score": 0.21, "rank": 1}, "...33 nums..."],
  "blue": [{"num": 12, "score": 0.09, "rank": 1}],
  "ticket_example": {"red": [7, 11, 18, 21, 29, 32], "blue": [12]},
  "null_hit6_expectation": 1.0909,
  "disclaimer": "研究样本，非开奖预测，非投注建议。购彩有风险。",
  "randomness_test_p_chi2": 0.42
}
```

前端展示分数条，不允许只展示 6 个号而不展示零模型期望。

### 8.6 模型选择规则

- 生产默认展示 M0 与 M1 与 M3 三列。
- 仅当 walk-forward 上 M3 的 Hit@6 均值相对 M0 的 z>3 **且** 泄漏测试通过 **且** χ² 同步拒绝均匀，才把文案从“对照实验”升级为“检测到频率偏差，见检验页”。仍不写“推荐购买”。

---

## 9. 回测框架

### 9.1 原则

1. 时间单向。
2. 先定策略再看数，禁止根据 test 调 W。
3. 成本真实扣 2 元 × 注数。
4. 派奖用官方规则函数 `grade(red_pred, blue_pred, red_real, blue_real)`。
5. 同一随机种子可复现。
6. 禁止未来函数：策略在 t 开奖前锁票。

### 9.2 `BacktestEngine` 接口

```python
class Strategy(Protocol):
    id: str
    def tickets(self, ctx: Context) -> list[Ticket]:
        """ctx 含 features asof t、历史 draws < t、预算。不得读 t 的开奖。"""

class Ticket(BaseModel):
    red: tuple[int, ...]
    blue: tuple[int, ...]
    stake_yuan: Decimal = Decimal("2")
```

内置策略：

| strategy_id | 行为 |
| --- | --- |
| `uniform_1` | 每期 1 注均匀随机（无放回组合） |
| `freq_top6_w100` | 近 100 期热号 |
| `cold_top6` | 遗漏最大 |
| `lgbm_top6` | 模型 top6 |
| `lgbm_sample` | 按 softmax(score/T) 无放回采样 1 注 |
| `wheel_n10` | 覆盖模块出 10 注（P1） |

### 9.3 Walk-forward 过程

```
输入：draws[0..T-1] 已排序
参数：min_train=800, step=1 或 20, tickets_per_draw=1
for t in range(min_train, T):
    lock features_t from draws[:t]
    tickets = strategy.tickets(ctx_t)
    assert 不包含 draws[t] 号码来源
    reward = sum(prize(ticket, draws[t]) for ticket in tickets)
    cost = 2 * len(tickets)
    record(hit_red, hit_blue, grade, reward, cost)
汇总：ROI, 最大回撤, 奖级直方图, Hit@6 均值与 95% CI, vs Hypergeometric G-test
```

### 9.4 资金曲线

假设初始资金 10000 元，每期固定 1 注，不允许借注。资金 < 2 元则停止，记 `ruin=true`。这是演示风险，不是投资建议。

### 9.5 对照与多重检验

同时跑 M0/M1/M2/M3。报告 ΔHit@6 时用配对检验（同期差值）。4 个策略 × 多个窗口会膨胀显著性：主报告只锁 `W=100`、`tickets=1`。其他进附录。

### 9.6 回测产物

`backtest_run.metrics`：

```json
{
  "n": 500,
  "hit6_mean": 1.088,
  "hit6_ci95": [1.012, 1.164],
  "hit6_expected": 1.0909,
  "z_vs_null": -0.07,
  "grades": {"0": 0.35, "1": 0.44, "2": 0.18, "3": 0.025, "4": 0.001, "5": 0, "6": 0},
  "cost_yuan": 1000,
  "payout_yuan": 480,
  "roi": -0.52,
  "max_drawdown_yuan": 640,
  "ruin": false,
  "prize_imputed_rate": 0.02
}
```

### 9.7 正确性自测（CI 必过）

1. `uniform_1` 在 2000 期模拟开奖（真随机生成，不是历史）上 Hit@6 落入理论区间。
2. 把策略改成“偷看当期红球” → Hit@6=6，ROI 大正。此用例证明框架能抓住作弊；生产策略跑此测试必须失败（不能偷看）。
3. 成本：500 期 1 注 cost==1000。
4. 奖级映射 18 格快照测试。

---

## 10. 评估指标

分三层，禁止混用。

### 10.1 号码排序层（模型）

| 指标 | 定义 | 好的样子 |
| --- | --- | --- |
| Hit@6 | 预测 top6 与开奖红球交集大小 | 均值→1.091 |
| NDCG@6 | 排序质量 | 贴近随机 NDCG |
| AP | 33 个号的平均精度 | 近随机 |
| Brier | `mean((p_i - y_i)^2)` | 近 `p(1-p)=0.1488`（若恒报 6/33） |
| LogLoss | 逐号 | 不低于恒报 p 的 logloss |
| 校准 | 分箱可靠度图 | 落在对角 |
| 覆盖蓝球 Top1 命中率 | 均值→1/16=0.0625 | |

恒报 p 的 Brier：`p(1-p)=6/33 * 27/33 ≈ 0.14876`。模型 Brier 必须跟这个比，而不是跟 0 比。

### 10.2 策略层（钱）

| 指标 | 定义 |
| --- | --- |
| ROI | (派奖-成本)/成本 |
| EV_hat | 同期平均净收益 |
| MaxDD | 资金曲线最大回撤 |
| Hit_grade_k | 各奖级频率 vs 理论 |
| Ruin | 是否破产 |
| Turnover | 每期注数 |

### 10.3 科学层（开奖器）

| 指标 | 定义 |
| --- | --- |
| χ² p 红/蓝 | 全程与滚动 200 期 |
| Ljung-Box 对单号 0-1 序列 | 滞后 1,2,5,10 |
| 游程检验 | 冷热切换 |
| KS | 和值分布 vs 理论卷积分布 |

### 10.4 展示规则

- 主仪表盘默认显示 **vs 零模型**，不显示“准确率 %”。
- 若有人要把 Hit@6=1.2 写成准确率 20%，拒绝。换算：随机已经 18.18% 的单号命中率，6 个号期望 1.09 个。
- 所有均值带 95% CI。T<100 的实验不进首页。

---

## 11. 可视化设计

技术：Recharts。色盲安全：红球用蓝绿编码在 UI 里不靠红绿对比区分冷热；号码圆点可用填充/空心。图表不出现“预测成功闪金”。

### 11.1 图表清单

| ID | 页面 | 图 | 数据 | 交互 |
| --- | --- | --- | --- | --- |
| V1 | 总览 | 资金曲线 4 策略 | backtest_run | hover 期号 |
| V2 | 总览 | Hit@6 滚动 50 期 | prediction×draw | 叠加理论均值与 CI 带 |
| V3 | 检验 | 33 条频率柱 + 水平线 E | draw_ball | 高亮偏离 |
| V4 | 检验 | 滚动 χ² p 值 | stats job | log 轴可选 |
| V5 | 检验 | 和值直方图 vs 理论 | draw | |
| V6 | 号码 | 33×年份 热力 | draw_ball | 点击号码出遗漏图 |
| V7 | 号码 | 共现矩阵 33×33 | 近 W 期 | |
| V8 | 模型 | 可靠度图 | prediction | |
| V9 | 模型 | 特征重要性 top20 | lgbm | 注明相关性≠因果 |
| V10 | 回测 | 奖级堆叠条 vs 理论 | backtest | |
| V11 | 回测 | Hit@6 分布直方图 vs 超几何 PMF | | |
| V12 | 研究票 | 33 个分数条 | latest prediction | 强制脚注 |

### 11.2 视觉规则

- 理论参考线永远画。缺参考线的图不许合入。
- 号码球：红球实心圆 + 两位数字，蓝球空心或另一色。排序升序。
- 表格数字 `tabular-nums`。
- 空态：未跑回测时显示“先跑 make backtest”，不要假曲线。

---

## 12. 后端 / API 设计

### 12.1 服务

```
uvicorn law.api.main:app --host 0.0.0.0 --port 8000
```

无用户体系。7 天不做登录。写操作（训练、抓取）用环境变量 `LAW_ADMIN_TOKEN` 的 header `X-Admin-Token`。读接口公开。

### 12.2 公共信封

```json
{
  "ok": true,
  "disclaimer": "历史统计分析，非开奖预测，非投注建议。",
  "data": {}
}
```

错误：`{ "ok": false, "error": { "code": "MISMATCH", "message": "..." } }`。HTTP 映射：400 校验、401 token、404、409 对账冲突、500。

### 12.3 路由

**GET /health**  
`{status, db, last_issue, last_ingest_at}`

**GET /api/v1/draws?lottery=SSQ&limit=50&before_issue=**  
分页历史。每项含 red/blue/date/sales。

**GET /api/v1/draws/{issue}**  
详情 + prize_json + sources。

**GET /api/v1/stats/summary?lottery=SSQ**  
χ²、p、T、E、偏离最大的 5 个号码。

**GET /api/v1/stats/frequency?pool=red&window=all|100**  
33 点。

**GET /api/v1/features/{issue}**  
该期 v1 特征（asof 上一期）。404 if 未物化。

**GET /api/v1/models**  
已注册模型及最新 metrics。

**GET /api/v1/models/{model_id}/predictions/{issue}**  
分数向量 + ticket_example + null 期望。

**GET /api/v1/backtests/{id}**  
metrics + 可选 downsample 的资金序列。

**GET /api/v1/research-ticket/next**  
对“下一期”（max_issue+逻辑下一期号）返回 M0/M1/M3 三票。  
**必须**带 `not_a_forecast: true`。

**POST /api/v1/admin/ingest**  
拉新。鉴权。

**POST /api/v1/admin/train**  
body: `{model_id, train_end_issue}`。异步：立即返回 `job_id`。

**POST /api/v1/admin/backtest**  
body: `{strategy_id, start_issue, end_issue, tickets_per_draw}`。

**GET /api/v1/jobs/{id}**

### 12.4 预测接口伪实现

```python
@router.get("/research-ticket/next")
def next_ticket(lottery="SSQ"):
    last = repo.latest_draw(lottery)
    feats = repo.features_asof(last.issue)
    scores = model_store[ "lgbm_rank_v1" ].predict(feats)
    return envelope({
        "asof_issue": last.issue,
        "target": "NEXT",
        "tickets": {
            "uniform": sampler.uniform(seed=last.issue),
            "freq": freq_top(last.issue, W=100),
            "lgbm": topk(scores, 6),
        },
        "hit6_null": 1.0909,
        "not_a_forecast": True,
    })
```

### 12.5 性能

- `/draws` 走索引。
- 分数预计算，接口不现场 train。
- 频率统计 5 分钟缓存或进程内 LRU。
- payload 列表默认 limit=50，max=200。

### 12.6 观测

结构化 log：`issue, action, ms`。`audit_log` 记所有 admin。不记 IP 以外的个人数据；7 天甚至可以不记 IP。

---

## 13. 前端页面设计

### 13.1 信息架构

```
/                   总览
/draws              开奖序列
/tests              随机性检验
/numbers            号码研究（频率/遗漏/共现）
/models             模型对照
/backtest           回测台
/research           下期研究样本（最强声明）
/method             方法论文档（本文摘要）
```

全局：顶栏项目名“彩研台 LAW”，副标题“开奖数据研究工作台”。页脚固定一句：  
**本系统不提供彩票预测或投注建议。18+。理性购彩。**

### 13.2 各页内容

**总览 /**  
KPI：入库期数、最新期号、红球 χ² p、LGBM Hit@6、Uniform Hit@6、ROI。  
图 V1、V2。  
不放“推荐号码”大卡片。

**开奖 /draws**  
表：期号、日期、6+1 球、销量。点入详情。筛选年份。

**检验 /tests**  
V3 V4 V5 + 文字结论模板：  
`当前全样本红球 χ² p=…，不能拒绝均匀假设 / 拒绝均匀假设（见偏差号码）。即使拒绝，也不构成可下注边缘，除非偏差在 walk-forward 中稳定且转换为正 EV（预期不会）。`

**号码 /numbers**  
选号码看遗漏轨迹。热力 V6。共现 V7。

**模型 /models**  
三列对照表。可靠度图。特征重要性。下载 `metrics.json`。

**回测 /backtest**  
选择 strategy、区间、注数（上限 10）。提交 admin 或展示最近一次离线结果。V10 V11。显示破产与 MaxDD。

**研究样本 /research**  
三组号 + 分数条。页面顶部 16px 固定告示：

> 以下号码是历史统计规则的输出样本，用于对照实验。它们不是对未来开奖的预测，也不构成购买建议。随机选号与模型选号在无偏开奖下期望相同。

按钮文案用“生成研究样本”，禁用“预测”“智能选号”“一键跟单”。

**方法 /method**  
第 3 章摘要 + 超几何公式 + 链接下载本设计文档。

### 13.3 组件

```
AppShell
  DisclaimerBar
  Nav
  Page
    StatCard (仅数字 KPI)
    BallSet
    ChartCard (强制 legend 含理论线)
    DataTable
    ModelCompareTable
    ResearchTicketPanel
```

移动端：Nav 底栏 5 项（总览/开奖/检验/回测/研究），其余进更多。球号触控目标 ≥ 32px，页脚声明不缩小到难以阅读。

### 13.4 前端状态

TanStack Query。无登录。Admin 训练按钮仅当 `localStorage.LAW_ADMIN_TOKEN` 存在才显示，默认隐藏。

---

## 14. 风险与合规说明

### 14.1 法律与监管（产品必须遵守的工程约束）

- 彩票是国家特许发行。私自销售彩票、返奖、代购违法。
- 不得宣传“保证中奖”“预测开奖结果”。页面、API、README、OG 文案同步禁止。
- 不向未成年人提供购彩引导。写 18+。
- 本项目定位为**数据处理与统计研究工具**，类似随机性实验台，不是彩票投注工具。
- 抓取公开开奖信息：控制频率、保留来源、不绕过明确禁止项。若源站 ToS 禁止，改用官方下载/手工黄金集。

### 14.2 功能红线（代码层）

| 红线 | 实现 |
| --- | --- |
| 支付/代购 | 不出现相关路由 |
| “必中”文案 | i18n 词表黑名单 CI grep |
| 自动推送下期号 | 不做通知系统 |
| 隐瞒零模型 | 研究页强制并排 Uniform |
| 用测试集调参后只报最好一次 | 主指标预注册在 yaml |

### 14.3 统计风险

- p-hacking：窗口、模型、种子。对策：yaml 预注册 + 附录隔离。
- 泄漏。对策：leak_check CI。
- 用户把负 ROI 当暂时回撤。对策：MaxDD 与 ruin 默认展示。
- 开奖规则/奖级调整。对策：派奖版本化，按日期切规则。

### 14.4 运营风险

- 源站改版导致空库：health 检查 `last_draw_age > 8d` 告警。
- 模型被媒体截图成“AI 预测”。对策：截图水印与 `not_a_forecast`。
- 依赖 LightGBM 版本：锁 `lightgbm==4.x` 于 pyproject。

### 14.5 伦理

明知 EV 为负仍做“提高中奖率”产品，属于有意误导。本设计选择把负结论产品化。若需求方强制要求荐号销售，拒绝实施。

---

## 15. 7 天开发计划

单人全栈，每天按 8 小时。每日有可运行产物。不做环境漂移。

### Day 1 星期一 · 数据底座

- 建仓、pyproject、ruff、pytest、docker-compose Postgres。
- Alembic 初迁：`lottery/draw/draw_ball/draw_source`。
- 实现 `ssq_500` 解析器 + 磁盘 raw + upsert。
- 夹具 HTML 3 期进 `tests/fixtures`。
- 目标：`make ingest` 入库 ≥ 2500 期，`pytest tests/test_invariants.py` 绿。

验收：`SELECT COUNT(*) FROM draw WHERE lottery_code='SSQ'` ≥ 2500；BAL-01~05 全过。

### Day 2 星期二 · 对账、QA、统计零模型

- `ssq_cwl` 或第二源；`reconcile.py`。
- `hypergeometric.py` 实现 PMF/期望，与手算表对 6 位小数。
- χ²、滚动 p、单号 ACF。
- 导出 `data/processed/ssq_draws.parquet`。
- 目标：`GET /api/v1/stats/summary` 原型（可先函数后挂路由）。

验收：理论 E[X]=1.090909 断言；χ² 在模拟均匀数据上 p 不系统性 <0.05。

### Day 3 星期三 · 特征

- `registry.py` + `ssq_draw.py` 物化 v1。
- `leak_check`：未来列相关测试、asof_issue < target。
- 行表 `rank_rows.parquet`（每期 33 行）。
- 目标：特征构建 `make features` < 2 min。

验收：随机抽 20 期，手算 `freq_i_10` 一致；泄漏测试绿。

### Day 4 星期四 · 模型

- M0 M1 M2 M3。
- 固定切分 last 500 期 test；step=20 walk。
- 产出 `model_run` 与 `prediction`。
- 目标：三模型 Hit@6 表。

验收：M0 在历史回测上 Hit@6∈理论 95% 带（允许一次复现种子）。M3 不得使用 test 调 `num_leaves`。

### Day 5 星期五 · 回测与派奖

- `prizes.py` 18 格单测。
- `walker.py` + 资金曲线。
- 策略 YAML 预注册。
- 目标：`make backtest` 写出 metrics.json。

验收：cost 公式；偷看策略测试；主策略 ROI<0（预期）。若 ROI>0，当天只查 bug，不写新闻。

### Day 6 星期六 · API + 前端壳

- FastAPI 全部 GET。
- Admin POST + token。
- 前端 AppShell、总览、开奖、检验。
- 目标：docker-compose up 后浏览器可看历史球与 χ²。

验收：OpenAPI 生成；公开路由无写。

### Day 7 星期日 · 回测页、研究页、合规、文档

- 模型页、回测页、研究样本页、方法页。
- 文案黑名单 grep。
- README：如何跑、如何不宣传。
- 打包：`make report` 生成 PDF/MD 指标摘要。
- 目标：演示 10 分钟路径：总览 → 检验 p 值 → 回测 ROI → 研究样本声明。

验收：第 2.2 节表格逐条勾。演示脚本写入 `docs/demo.md`。

### 并行与砍削

若 Day 1 源站失败：改用预置 parquet（工程内置 ≥2500 期公开历史快照），Day 1 仍完成入库。爬虫降为 P1。  
若 Day 4 来不及 walk step=20：只交固定切分，walk 在 README 标 TODO，不阻塞前端。  
砍削顺序：GNN/LSTM → DLT → 覆盖设计 → 第二数据源。不砍：零模型、泄漏检查、免责声明。

### 每日结束命令

```
make test
make ingest   # 幂等
docker compose ps
```

---

## 16. 项目亮点总结

1. **先写不可行性，再写系统。** 把超几何零模型做成第一公民，而不是准确率仪表盘。
2. **可证伪。** χ²、泄漏置换、偷看策略反测、Uniform CI 带，四道闸。
3. **标签正确。** 排序学习 33 行/期，不用 1700 万分类，不用一等奖分类。
4. **回测像交易系统。** 成本、派奖、回撤、破产，而不是“对了几个号”。
5. **特征版本化与 asof。** 数仓纪律可迁移到真正的金融/风控项目。
6. **双源对账。** 把开奖当支付核心数据而不是爬来就训。
7. **合规内建。** API 信封、研究页文案、词表 CI，避免项目本身变成赌具。
8. **7 天范围锁死。** 三个模型、一个特征版本、一个玩法主线，能做完也能讲完。
9. **负结果可展示。** 产品完成态是“模型≈随机，ROI≈负”，这对作品集比假神机更强。
10. **覆盖优化留在 P1。** 把真正的工程问题（组合覆盖）和伪问题（预测随机数）切开。

---

## 附录 A · 派奖判定参考实现

```python
def ssq_grade(red_h: int, blue_h: int) -> int:
    # return 1..6 or 0
    if red_h == 6 and blue_h == 1: return 1
    if red_h == 6 and blue_h == 0: return 2
    if red_h == 5 and blue_h == 1: return 3
    if (red_h == 5 and blue_h == 0) or (red_h == 4 and blue_h == 1): return 4
    if (red_h == 4 and blue_h == 0) or (red_h == 3 and blue_h == 1): return 5
    if blue_h == 1 and red_h <= 2: return 6
    return 0
```

固定奖金默认：3=3000，4=200，5=10，6=5（元/注）。1、2 等奖用该期 `per_stake_yuan`。

## 附录 B · Makefile 最小集

```
ingest:     python -m law.ingest.cli --lottery SSQ
features:   python -m law.features.cli --version v1
train:      python -m law.models.train --model lgbm_rank_v1
backtest:   python -m law.backtest.cli --strategy lgbm_top6,uniform_1,freq_top6_w100
api:        uvicorn law.api.main:app --reload --port 8000
test:       pytest -q
report:     python -m law.backtest.report --out data/processed/report.json
```

## 附录 C · 上线前 20 条检查

1. 无“预测中奖”文案  
2. 研究页有 `not_a_forecast`  
3. Uniform 与模型并排  
4. Hit@6 有 CI  
5. ROI 含成本  
6. 泄漏 CI 绿  
7. 偷看策略测试存在且生产策略失败该测试  
8. 超几何表打印与文档一致  
9. 双源或 SINGLE_SOURCE 标记可见  
10. 号码约束触发器或等价断言  
11. raw hash 可追溯  
12. 特征 version 字段  
13. admin 写接口鉴权  
14. 无支付代码  
15. 18+ 页脚  
16. health 含 last_issue  
17. 滚动 χ² 图有参考  
18. LightGBM 种子写入 model_run  
19. 预注册 yaml 未被临时改 W  
20. README 写明 EV 为负  

## 附录 D · 演示讲稿（10 分钟）

1. 打开总览：期数、最新开奖球。说明数据对账。  
2. 检验页：p 值，解释不能拒绝均匀。  
3. 模型页：Hit@6 ≈ 1.09，三模型重叠。  
4. 回测：ROI 约 -50% 量级，MaxDD。  
5. 研究样本：读出红色声明，解释三票期望相同。  
6. 收尾：本项目证明的是科学方法，不是玄学号源。

---

文档结束。实现以本文 V1.0 为准；与本文冲突的“提高准确率”需求一律拒绝。

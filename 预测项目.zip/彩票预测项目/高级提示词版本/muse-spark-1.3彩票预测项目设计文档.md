# 彩票预测项目科学实现方案 — 高级数据工程师/机器学习工程师设计文档

版本: v1.0 | 作者: Senior DE/MLE | 日期: 2026-09-11 | 状态: 可进入开发

---

## 1. 项目背景

- 对象: 以双色球、大乐透为代表的数字型乐透彩票。每期独立开奖，规则公开。
  - 双色球: 33选6红球 + 16选1蓝球，理论组合 17,721,088
  - 大乐透: 35选5前区 + 12选2后区，理论组合 21,425,712
- 现状: 市面“预测软件”多为伪随机推荐+玄学指标，无回测、无置信度、无合规声明，误导用户。
- 机会: 用正规数据工程 + 统计学 + 可解释ML，做一个“诚实、透明、可验证”的彩票数据分析系统。核心价值不是提高命中率，而是：数据透明化、谬误教育、理性购彩、工程示范。

## 2. 项目真实目标

必须书面明确，避免伪科学：

- 真目标G1(数据): 建立全量、可追溯、可增量更新的开奖数据库，准确率100%。
- 真目标G2(统计): 证明任何模型期望收益为负，提供可复现的证据。
- 真目标G3(工程): 交���回测框架+API+可视化，让任何“策略”可被证伪。
- 真目标G4(产品): 提供娱乐型“随机选号+预算管理”工具，降低用户上头风险。
- 非目标: 不承诺提高中奖率，不提供“必中、稳赚、内幕”功能，不做自动投注/合买资金池。

成功标准:
- 回测覆盖 >2000期，策略期望ROI与理论值误差 <1%。
- 模型Top1命中率与随机基线差异在显著性检验 p>0.05。
- 系统支持日更，API p95 <300ms。

## 3. 彩票预测是否可行的统计学解释

结论先行: 在独立均匀随机假设下，不可预测，不存在长期正期望策略。

1. 独立性: 摇奖机物理独立，P(X_t | X_{t-1}...X_1)=P(X_t)。“热号冷号追号”无记忆性，属赌徒谬误。
2. 均匀性: 合规彩票每个组合等概率。双色球头奖概率 1/17721088 ≈ 5.64e-8。买1注期望返奖 ≈ 0.5元(按50%返奖率)，期望净收益 -0.5元/注。
3. 大数定律: 短期偏离(连号、重号)必然出现。n=2000期时，某红球理论出现次数 = 2000*6/33 ≈363.6，标准差 sqrt(np(1-p))≈17.4，±2σ波动±35属正常。
4. 卡方检验: 对33红球做均匀性检验，χ²=Σ(O-E)²/E，df=32。若p>0.05不能拒绝均匀假设。历史实测双色球/大乐透均未偏离均匀。
5. 互信息≈0: I(X_t; X_{t-1})���置换检验≈0，滞后自相关ACF落入白噪声带。
6. 为何“模型准确率看起来高”: 预测“不出现”某号码准确率天然 27/33=81.8%，属基率谬误。必须对比随机基线、做显著性检验。
7. 唯一数学正EV场景: 奖池累积+多人分摊折损后的罕见套利，国内规则下不可操作，且需全包(1772万注，成本3544万)，无工程意义。

工程含义: 本项目所有模型必须带随机基线对照和置信区间，否则视为无效。

## 4. 可落地项目定位

定位: **Lottery Analytics & Responsible Play Platform**，四象限:

- A. 开奖数据中心: 历史查询、遗漏统计、API。
- B. 伪策略证伪实验室: 任何选号策略一键回测，打脸报告。
- C. 娱乐选号器: 真随机/伪随机+过滤条件(和值、跨度、连号)，明确标注娱乐。
- D. 理性购彩助手: 预算、限额、冷静期、期望计算器。

用户画像: 数据爱好者/课程大作业/购彩者(轻度娱乐)/面试作品。
商业化(合规): 广告+会员高级图表，不抽佣、不代购、不荐号收费。

## 5. 数据来源与字段设计

### 5.1 数据来源
- 主源: 中国福彩官网、体彩官网开奖公告页(爬虫+人工校对)。
- 备源: 500彩票网、新浪彩票历史API(仅交叉验证)。
- 更新: 每周二四日(双���球) / 一三六(大乐���) 21:30后 cron 抓取，重试3次。
- 存档: 原始HTML快照存OSS/R2，保留hash防篡改。

### 5.2 表设计 (Postgres)
```sql
-- 期次主表
CREATE TABLE draws (
  lottery VARCHAR(16), -- SSQ, DLT
  issue VARCHAR(16) PRIMARY KEY, -- 2026001
  draw_date DATE NOT NULL,
  r1 INT, r2 INT, r3 INT, r4 INT, r5 INT, r6 INT, -- DLT f1-f5
  b1 INT, b2 INT, -- SSQ仅b1
  sales BIGINT,
  pool BIGINT,
  first_prize_count INT,
  first_prize_amount BIGINT,
  source_url TEXT,
  created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE draw_raw_html (
  lottery VARCHAR(16), issue VARCHAR(16),
  html_hash CHAR(64), content TEXT, fetched_at TIMESTAMP
);
```

字段规范: 红球升序存储，校验范围 SSQ r 1-33 b 1-16；DLT f 1-35 b 1-12。issue+lottery唯一索引。

### 5.3 数据量估算
SSQ自2003年 ~2400期，DLT ~2500期，总行<1万，CSV<2MB。Postgres单表即可，无需大数据组件。

## 6. 数据清洗规则

R1. 去重: (lottery,issue)主键去重，保留source官方优先。
R2. 范围校验: 越界直接 quarantine 表，不入库。
R3. 排序归一: 红球排序后存，原始顺序存raw。
R4. 缺期检测: issue连续性检查，缺失发告警并标记is_missing。
R5. 交叉验证: 主备源号码不一致 -> 人工review表，双人确认。
R6. 金额清洗: “元”转分/元int，空值填-1并标记未知。
R7. 日期校验: draw_date必须为开奖 weekday，否则告警。
R8. 幂等写入: ETL以issue为key做upsert，支持重跑。
R9. 审计: 每次ETL写etl_logs(行数、hash、耗时、操作人)。
R10. 单元测试: 3个失败用例先fail再pass: 越界号、重复期、乱序号。

ETL: Python + httpx + BeautifulSoup + pydantic + SQLAlchemy，GitHub Actions cron触发。

## 7. 特征工程清单

只做描述性/娱乐性特征，禁止暗示因果。窗口 W=[10,30,50,100]。

- 基础: 和值 sum_r, 跨度 max-min, 奇偶比 odd_ratio, 大小比, AC值, 连号数, 重号数(与上期交集), 012路比。
- 遗漏: omission_i = 当前期距上次出现间隔；max_omission_W, avg_omission。
- 频率: freq_W = W内出现次数 / (W*6/33) 标准化；hot_score=z-score。
- 间隔: 上次间隔、平均间隔、方差。
- 组合: 尾数分布(0-9), 区间分布(1-11/12-22/23-33), 蓝球遗漏。
- 时间: weekday one-hot, issue_mod(除10余数)仅作展示。
- 禁用特征: 生肖、星座、梦境、幸运色等伪特征不进入模型，只作前端彩蛋需标注迷信。

特征表 `features_ssq` 按issue主键宽表存储，离线批量计算，版本化 feature_version=v1。

## 8. 模型方案对比

所有模型统一输出: 下期6+1概率分布或Top-N推荐 + 置信度，并强制与随机基线对比。

| 方案 | 原理 | 预期结果 | 用途 | 成本 |
|---|---|---|---|---|
| M0 随机基线 | numpy真随机 | ROI≈-50% | 对照组，必须有 | 极低 |
| M1 频率统计 | 近W期高频选号 | ≈随机，无显著提升 | 证伪“热号法” | 低 |
| M2 马尔可夫/贝叶斯 | Dirichlet-Multinomial平滑 | 后验趋近均匀 | 教学贝叶斯 | 低 |
| M3 时间序列 ARIMA/LSTM | 把开奖当序列预测 | RMSE≈随机，方向准确率~50% | 证明序列不可学 | 中 |
| M4 XGBoost分类 | 每球二分类(出现/不出现) | AUC≈0.5，logloss≈基线 | 展示过拟合风险 | 中 |
| M5 VAE/GAN生成 | 学历史分布生成组合 | 生成分布≈均匀 | 娱乐生成器 | 高 |
| M6 组合优化 | 避热门号减少分摊(非提高概率) | 中小奖分摊略优，期望仍负 | 唯一有点用的策略 | 低 |

建模规范:
- 按时间切分: train<2022, valid 2023-2024, test 2025-至今，禁shuffle。
- 评估: 每个模型跑1000次bootstrap+置换检验。
- 上线: 仅M0+M6可进“推荐”页，其余进“实验室”页标注准确率≈随机。

## 9. 回测框架

设计: 事件驱动、免未来函数、手续费/税费建模。

```python
# 伪代码
for issue in test_issues:
  pred = strategy.predict(history_before_issue) # 只能用历史
  prize = settle(pred, actual[issue], prize_table) # 按官方奖级表
  equity.append(prize - cost)
ROI = sum(equity)/total_cost
```

- 奖级表: 内置SSQ/DLT 1-6等奖规则+税(1万以上20%)。
- 策略接口: `class Strategy: def predict(hist: DataFrame)->List[int]`
- 内置策略: random, hot_W30, cold_W30, overdue(遗漏最大), fixed(守号), avoid_popular。
- 防作弊: 回测引擎校验predict访问期号，引用未来直接fail。
- 输出: equity曲线、最大回撤、破产概率、蒙特卡洛10000次模拟。
- CLI: `python backtest.py --lottery SSQ --strategy hot30 --from 2020-01-01 --stake 2`

## 10. 评估指标

- 命中类(需配基线): 单球命中率、6+1全中率、平均命中红球数。随机基线: 平均命中 6*6/33=1.09个。
- 财务类(核心): ROI, 年化(无意义但展示为负), 最大连亏期数, 资金破产概率(Kelly公式证明最优投注为0)。
- 统计类: 卡方p值、AUC(应≈0.5)、Brier score(应≈基线)、置换检验p值。
- 工程类: ETL成功率>99.5%，API p95<300ms，数据延迟<2h。
- 判定规则: 策略ROI高于随机且p<0.05持续3个独立时间段才算“异常”，否则判为噪声。至今无策略达标。

示例报告话术: “hot30策略2400期ROI -52.3%，随机基线 -51.1%，差异p=0.42，无显著优势。”

## 11. 可视化设计

技术: ECharts + React，前后端分离。

- P1 开奖大厅: 日历热力图+号码球渲染，支持issue检索。
- P2 号码分布: 33红球频率柱状图+理论线(363±35带)，蓝球分布。
- P3 遗漏仪表: 当前遗漏Top10，最大遗漏历史排行。
- P4 和值/跨度走势: 折线+移动平均W30，标注±σ带。
- P5 回测实验室: equity曲线(策略vs随机双线)，ROI对比柱，蒙特卡洛直方图。
- P6 期望计算器: 输入注数/期数，输出期望花费/返奖/亏损概率滑块。
- 规范: 每张预测相关图下方强制脚注“历史不代表未来，独立随机事件”。

## 12. 后端/API设计

栈: FastAPI + Postgres + Redis缓存 + Celery beat调度。

```
GET /api/v1/draws?lottery=SSQ&from=2024-01-01&limit=100
GET /api/v1/draws/{issue}
GET /api/v1/stats/frequency?lottery=SSQ&window=100
GET /api/v1/stats/omission?lottery=SSQ
POST /api/v1/backtest {lottery,strategy,from,to,stake} -> {roi,equity,report_id}
GET /api/v1/random-pick?lottery=SSQ&count=5&filter={sum_range}
GET /api/v1/health -> {status:ok, db_lag_sec}
```

- 鉴权: 读公开，backtest限流 10/min/IP，写操作Admin Key。
- 缓存: stats接口Redis TTL 1h，draws永久缓存+版本。
- 部署: Docker Compose，Cloudflare Worker反向代理，不绑根域名，用 api.lotto.example.com。
- 配置: env `DB_URL, REDIS_URL, CRON_TOKEN` 三处一致，README列出。

## 13. 前端页面设计

路由(Next.js):

- `/` 首页: 一句话“我们证明你赚不到钱”+期望计算器+最新开奖。
- `/draws` 历史查询: 表格+筛选+CSV导出。
- `/analytics` 统计图表(P2-P4)。
- `/lab` 策略实验室: 选策略->跑回测->看打脸报告(PDF导出)。
- `/pick` 娱乐选号: 随机5注+过滤+复制，不显示“胜率”。
- `/responsible` 理性购彩: 预算设置、冷静期提醒、求助热线。
- UI: 移动优先，号码球组件，暗色模式。每个预测页顶部黄条警告。

## 14. 风险与合规说明

- 法律: 仅做历史数据展示与科普，不代销、不合买、不收单。中国需《彩票管理条例》合规，不触碰发行销售。
- 宣传: 禁用“必中/稳赚/内幕/包中”词汇，违者下线。显著位置写“彩票期望为负，购彩属娱乐消费”。
- 未成年人: 18岁以下弹窗拦截，理性页引导。
- 数据: 注明来源官网，免责“数据仅供学习，官方公告为准”。
- 财务: 不提供自动投注接口，不对接支付分账。
- 安全: 公网API加限流+输入校验，不暴露���追踪。密钥只存环境变量。
- 心理风险: 预算工具默认单周上限50元，超限弹窗冷静24h提示。

## 15. 7天开发计划

- D1 数据层: 建表draws+ETL爬虫(SSQ近500期)，完成清洗R1-R8，产出CSV+README。验证: `pytest 47 passed`。
- D2 特征+统计: 实现特征清单W30/W100，跑卡方+自相关检验，输出均匀性报告。验证: p值复现。
- D3 回测引擎: Strategy接口+settle奖级表+random/hot/cold策略，跑2000期回测。验证: ROI≈-50%。
- D4 模型基线: M0+M1+M4(XGB)时间切分训练，输出AUC≈0.5证据图。验证: test logloss。
- D5 后端API: FastAPI 6接口+Redis缓存+Docker，部署 staging。验证: `/health 200 {status:ok}`。
- D6 前端: Next.js 4页(draws/analytics/lab/pick)+ECharts 5图。验证: 真实URL访问。
- D7 联调+文档: 端到端 cron->ETL->API->前端，写README+continue文档+合规文案，发v0.1 tag。

人力: 1全栈+0.5数据，日站会15min。每晚产出progress.md。

## 16. 项目亮点总结

- 诚实: 唯一敢用统计证明“预测无效”的彩票项目，面试/作品差异化拉满。
- 闭环: 数据->特征->模型->回测->API->前端，全链路可跑，非PPT架构。
- 证伪: 回测框架是核心资产，任何玄学一键打脸，可扩展到美股/竞彩教学。
- 合规: 理性购彩+限额+教育，规避法律与伦理雷区。
- 轻量: <1万行数据，单机Postgres+Vercel免费额度即可上线，成本≈0。
- 可讲: 故事线清晰：“我们花7天证明了彩票不能预测，但做了一个好工程。”

---

附: 快速开始
```bash
pip install -r requirements.txt
python etl/fetch_ssq.py --from 2003 --to now
python backtest.py --strategy random --lottery SSQ
uvicorn api.main:app --reload
```
License: MIT, 数据版权归发行机构。

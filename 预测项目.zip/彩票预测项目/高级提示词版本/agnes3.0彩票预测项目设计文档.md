# LotteryInsight — 彩票数据科学分析平台 · 设计文档

> 角色：高级数据工程师 / ML 工程师 | 版本 v1.0

---

## 1. 项目背景

双色球（红球 C(33,6) + 蓝球 1~16）自 2003 年发行，累计 3500+ 期，数据公开、结构固定。摇奖为独立随机事件，理论 EV < 0，任何模型无法持续击败随机基线。

但数据管道、统计检验、回测框架、可视化平台本身是**通用 ML 基础设施**，有独立工程价值。项目用彩票数据驱动可复用 pipeline，附带"哪些数字真的不随机"的统计洞察。

## 2. 项目真实目标

| 层级 | 交付物 | 验收标准 |
|------|--------|---------|
| 数据层 | 全量历史 + 每日增量 | 覆盖 2003 至今，增量延迟 < 5 min |
| 统计层 | 12 项随机性检验 | 输出 p-value 矩阵，标注 95% CI 偏离 |
| 模型层 | 3 基线 + 1 GBDT | 回测 Top-K 命中率 vs random 可量化 |
| 回测层 | Walk-forward 滑动窗口 | 支持任意 train/test 窗口参数 |
| 展示层 | Web 仪表盘 + REST API | 前端 6 页，API 12 端点 |
| 合规层 | 风险声明固定展示 | footer + API header |

**定位：不是"预测中奖号码"，是"用彩票数据搭可证伪的 ML pipeline + 统计洞察平台"。**

## 3. 彩票预测是否可行的统计学解释

**理论基准：** 双色球总组合 = C(33,6)×16 = 17,721,088。每期独立，P(命中) = 1/17.7M。模型若不能持续超越 random baseline → 无信息增益。

**12 项可检验假设：**

| # | 假设 | 方法 | 预期 |
|---|------|------|------|
| 1 | 频率均匀 | Chi-square / KS | 长期不显著 |
| 2 | 冷热号效应 | 滑动 30 期 vs 全局 | 大概率不显著 |
| 3 | 遗漏自相关 | Ljung-Box (lag=10) | 不拒绝 H0 |
| 4 | 趋势/季节 | ADF + STL | 无显著趋势 |
| 5 | 相邻期记忆 | 转移矩阵卡方 | 接近均匀 |
| 6 | 和值正态 | Shapiro-Wilk | 近似正态 (CLT) |
| 7 | 奇偶比 | 二项检验 | 接近 1:1 |
| 8 | 大小号比 | 二项检验 | 接近 1:1 |
| 9 | 连号频率 | 泊松拟合 | 低频非零 |
| 10 | 同尾号 | 组合计数 | 接近理论值 |
| 11 | 区间分布 | 多比例检验 | 近似均匀 |
| 12 | 蓝球周期 | FFT 频谱 | 无显著峰 |

**工程结论：** 模型输出定位为概率分布估计，非确定性预测。若某号偏离 95% CI → 记录为物理偏差信号，不作投注建议。核心产出 = "是否显著优于随机"的 verdict。

## 4. 可落地项目定位

```
项目名：LotteryInsight
定位：Data-Driven Lottery Analytics Platform
```

功能边界：
- 历史数据管理与统计检验
- 概率模型训练与回测
- 可视化仪表盘 + API
- 不输出"下期推荐号码"，不提供投注建议，不鼓励赌博

## 5. 数据来源与字段设计

**数据源：**
- 500.com 历史 CSV（全量 3500+ 期）
- 中国体彩官网 HTML（每日增量）
- GitHub Actions cron 每日 21:30 增量抓取

**核心表：**

```sql
CREATE TABLE ssq_draw (
    id INT PRIMARY KEY AUTO_INCREMENT,
    issue_no VARCHAR(16) UNIQUE,
    draw_date DATE NOT NULL,
    red_1 TINYINT, red_2 TINYINT, red_3 TINYINT,
    red_4 TINYINT, red_5 TINYINT, red_6 TINYINT,
    blue_1 TINYINT,
    sales_amt DECIMAL(12,2),
    pool_amt DECIMAL(12,2),
    prize_1_num INT DEFAULT 0,
    prize_1_amt DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE ssq_feature (
    issue_no VARCHAR(16) PRIMARY KEY,
    sum_val SMALLINT,
    odd_cnt TINYINT, big_cnt TINYINT,
    zone_a TINYINT, zone_b TINYINT, zone_c TINYINT,
    consec_cnt TINYINT, same_tail TINYINT,
    gap_max TINYINT, gap_mean DECIMAL(4,2),
    blue_miss TINYINT, pool_zscore DECIMAL(6,2),
    updated_at TIMESTAMP DEFAULT NOW()
);
```

## 6. 数据清洗规则

```python
def clean_draw(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop_duplicates(subset=['issue_no'], keep='last')
    # 范围校验
    df = df[(df[['red_1','red_2','red_3','red_4','red_5','red_6']].min(axis=1) >= 1) &
            (df[['red_1','red_2','red_3','red_4','red_5','red_6']].max(axis=1) <= 33) &
            (df['blue_1'].between(1, 16))]
    # 红球去重 + 升序
    reds = ['red_1','red_2','red_3','red_4','red_5','red_6']
    df[reds] = df[reds].apply(lambda r: sorted(set(r)), axis=1)
    df = df.dropna(subset=['issue_no','draw_date'])
    df.loc[df['sales_amt'] < 0, 'sales_amt'] = np.nan
    return df.sort_values('draw_date').reset_index(drop=True)
```

规则：每期 6 红 + 1 蓝，红球不重复 [1,33]；缺失 >5% 整行丢弃；时间序列按 draw_date 严格升序。

## 7. 特征工程清单

| 类别 | 特征 | 计算 |
|------|------|------|
| 和值 | sum_val | 6 红球之和 (15~159) |
| 奇偶 | odd_cnt | 奇数个数 (0~6) |
| 大小 | big_cnt | >16 的个数 |
| 三区 | zone_a/b/c | 1-11 / 12-22 / 23-33 各区个数 |
| 连号 | consec_cnt | 相邻差=1 的组数 |
| 同尾 | same_tail | 尾数相同对数 |
| 间隔 | gap_max / gap_mean | 排序后相邻差 |
| 遗漏 | miss_val | 该号距上次出现期数 |
| 频率 | freq_30 / freq_100 | 近 30/100 期出现次数 |
| 和值偏移 | sum_zscore | (sum - 全局均值)/标准差 |
| 蓝球 | blue_miss | 蓝球遗漏值 |
| 时间 | dow / month | 星期几 / 月份 |
| 奖池 | pool_zscore | 奖池金额 z-score |

输出：每行 1 期，约 15 维特征向量。

## 8. 模型方案对比

| 模型 | 实现 | 训练时间 | 预期表现 |
|------|------|---------|---------|
| Random Baseline | 均匀采样 6+1 | <1s | AUC≈0.5 |
| 频率模型 | 近 200 期高频号 Top6 | <1s | 略高于 random |
| 马尔可夫链 | 二阶转移矩阵 P(i→j) | <5s | 接近 random |
| LightGBM | 15 维特征 → 33 类多分类 | ~30s | 可能接近 random |

**训练策略：**
- Walk-forward：train=前 N 期，test=后 M 期，滑动 50 期
- 多分类：33 个红球各一个二分类 head，取 Top6
- 蓝球：16 类 softmax
- 超参搜索：Optuna 100 trials，目标 = test AUC

**判定：所有模型 AUC 若 < 0.55（vs random 0.5），verdict = "不显著优于随机"（预期结果）。**

## 9. 回测框架

```python
class WalkForwardBacktest:
    def __init__(self, data, model, train_window=500, test_window=50, step=50):
        self.data, self.model = data, model
        self.tw, self.stw, self.step = train_window, test_window, step

    def run(self) -> pd.DataFrame:
        rows = []
        for start in range(self.tw, len(self.data)-self.stw, self.step):
            train = self.data.iloc[start-self.tw:start]
            test  = self.data.iloc[start:start+self.stw]
            self.model.fit(train)
            pred  = self.model.predict(test)
            rows.append({
                'fold': start,
                'top5_hit': self._count_hit(pred, test, k=5),
                'top10_hit': self._count_hit(pred, test, k=10),
                'auc': self._compute_auc(pred, test),
            })
        return pd.DataFrame(rows)

    def verdict(self, results: pd.DataFrame) -> str:
        mean_auc = results['auc'].mean()
        if mean_auc > 0.55:  return "Significantly above random"
        elif mean_auc < 0.45: return "Below random (overfit)"
        else: return "Indistinguishable from random"
```

**回测报告输出：** 每 fold 的 top5/top10 命中率、AUC 均值±标准差、与 random 的配对 t-test p-value、最终 verdict 标签。

## 10. 评估指标

| 指标 | 定义 | 计算 |
|------|------|------|
| Top-K 命中率 | 预测 TopK 中实际包含的号码数 | mean(top5_hit)/6 |
| AUC (per-class) | 33 个二分类 macro-AUC | sklearn roc_auc_score |
| Log-Loss | 多分类交叉熵 | -mean(log(p_correct)) |
| 与随机对比 | 统计显著性 | paired t-test, α=0.05 |
| 覆盖率 | Top10 覆盖真实 6 个号概率 | P(hit≥4 in Top10) |
| 稳定性 | 各 fold 命中率方差 | std(top5_hit) |

判定阈值：AUC>0.55 且 p<0.05 → "有信号"；0.45<AUC<0.55 → "随机水平"（预期）；AUC<0.45 → "过拟合/负信号"。

## 11. 可视化设计

**前端 6 页面（Vue 3 + ECharts）：**

| 页面 | 内容 | 组件 |
|------|------|------|
| /dashboard | 最新开奖 + 检验摘要 + 模型状态 | Card + Line |
| /frequency | 33 号频率热力图 + 遗漏柱状图 | Heatmap + Bar |
| /statistics | 12 项检验结果 + p-value 分布 | Table + Box |
| /model | 各模型 AUC 曲线 + fold 明细 | Line + Table |
| /backtest | 回测结果 + verdict 标签 | Radar + Line |
| /about | 项目说明 + 风险声明 | 纯文本 |

交互：hover 频率图显示该号近 100 期出现次数 vs 理论期望；统计检验点击展开公式与结论；全局 footer 固定"仅供学习研究，不构成投注建议"。

## 12. 后端 / API 设计

**技术栈：** Python 3.11 + FastAPI + SQLAlchemy + PostgreSQL + Celery/Redis + Docker Compose

**API 端点（12 个）：**
```
GET  /api/v1/draws?limit=50          # 最新 N 期
GET  /api/v1/draws/{issue_no}        # 单期详情
GET  /api/v1/frequency?window=100    # 频率统计
GET  /api/v1/miss/{number}          # 指定号遗漏序列
GET  /api/v1/statistics             # 12 项检验结果
POST /api/v1/backtest/run           # 触发回测（异步）
GET  /api/v1/backtest/status/{id}  # 回测进度
GET  /api/v1/backtest/results       # 历史回测
GET  /api/v1/models                 # 模型列表+指标
GET  /api/v1/models/{name}/predict  # 输入近N期→概率分布
GET  /api/v1/health                 # 服务健康
GET  /api/v1/config/disclaimer      # 风险声明
```

异步：回测/训练走 Celery；每日增量抓取走 cron 21:05/21:30。安全：全接口加 X-Disclaimer-Notice header；predict 端点限流 10 req/min/IP。

## 13. 前端页面设计

- 框架：Vue 3 + Vite + Pinia + ECharts 5
- 布局：左侧导航 6 项，顶部面包屑，底部固定 disclaimer bar
- 配色：深色主题（#1a1a2e 背景），红球 #e74c3c，蓝球 #3498db
- 响应式：最小支持 1280px，移动端降级为表格视图
- 数据加载：轮询 /health 判断数据是否更新，更新后 refresh 全局 store

## 14. 风险与合规说明

- 本项目**仅供学习与研究**，不构成任何投注建议
- 彩票为独立随机事件，任何模型输出无正期望收益
- 不对用户因使用本项目产生的任何经济损失承担责任
- 所有页面 footer + API 响应 header 固定展示上述声明
- 不爬取需登录/付费数据源，仅使用公开数据
- 遵守 500.com 及体彩官网 robots.txt 与频率限制
- 数据存储仅保留开奖结果，不收集用户个人信息

## 15. 7 天开发计划

| Day | 任务 | 产出 |
|-----|------|------|
| D1 | 环境搭建 + 数据抓取脚本 + 全量入库 | DB 有 3500+ 期数据 |
| D2 | 清洗管线 + 特征工程 15 维 + 单元测试 | feature 表生成，pytest 全绿 |
| D3 | 12 项统计检验 + 报告生成 | statistics API 可用 |
| D4 | 3 基线模型 + LightGBM 训练 | model registry + 指标 |
| D5 | Walk-forward 回测框架 + verdict 逻辑 | backtest API 可用 |
| D6 | FastAPI 12 端点 + Celery + Docker | 后端完整部署 |
| D7 | Vue 前端 6 页 + 联调 + disclaimer + 文档 | 全栈可访问 |

每日验收：git commit + 对应测试通过 + 更新 progress.md。

## 16. 项目亮点总结

1. **可证伪性**：每个模型与 random baseline 对比，输出明确 verdict，不模糊
2. **12 项统计检验**：超越"跑个模型"的层面，深入随机性本质
3. **Walk-forward 回测**：非简单 train/test split，避免时间泄露
4. **完整工程管线**：抓取→清洗→特征→模型→回测→API→前端，可直接复用
5. **合规内建**：风险声明嵌入每个端点响应，不靠用户自觉
6. **预期诚实**：文档明确"大概率所有模型不显著优于随机"，不卖幻觉


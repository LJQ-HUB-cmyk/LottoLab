# 彩票预测项目的科学实现方案 — 项目设计文档

- 版本：v1.0
- 作者角色：高级数据工程师 / 机器学习工程师
- 交付形态：开源级作品集项目（数据分析平台 + 预测可行性验证沙箱）
- 技术栈：Python 3.11 / FastAPI / PostgreSQL 15 / Redis / Pandas / LightGBM / PyTorch / Vue3 + ECharts / Docker Compose

---

## 1. 项目背景

1. 彩票开奖数据具备三个工程友好属性：**公开、长期连续（双色球自 2003 年起 >3200 期）、强结构化**。是练手"采集→清洗→特征→回测→服务化→可视化"全链路的高性价比载体。
2. 市面上大量"彩票预测"产品利用信息不对称收割用户，从未有任何一个公开展示过可复现的回测证据。本项目的差异化定位：**用严谨的统计检验和防泄漏回测，量化回答"预测到底有没有信号"——包括证明它没有。**
3. 负结果（negative result）的可复现验证，本身就是 ML 工程能力的强展示：point-in-time 特征、walk-forward 回测、置换检验、多重比较校正，全部落地。
4. 系统架构与回测引擎可复用到低信噪比事件市场（随机抽取类、轮盘类）假设检验场景。

## 2. 项目真实目标

**分层目标（P0→P2）：**

| 层级 | 目标 | 交付物 | 优先级 |
|---|---|---|---|
| L0 数据管道 | 双色球/大乐透全量历史（≥15 年）自动采集、清洗、入库、质量监控 | 采集器 + DQC 报表 | P0 |
| L1 探索分析 | 频率、遗漏、和值、AC 值、区间分布、共现网络 | 4 个 EDA notebook + 图表 | P0 |
| L2 假设检验 | 均匀性/独立性/平稳性检验，给出"开奖是否可预测"的统计结论 | 检验报告（含 p 值） | P0 |
| L3 模型对照 | 随机基线 vs 6 类模型在同一 walk-forward 回测下对比 | 回测引擎 + 模型榜单 | P0 |
| L4 服务化 | REST API + 前端分析平台 + "娱乐式选号"功能（强制披露不确定性） | FastAPI + Vue 站点 | P1 |
| L5 内容化 | README、结果解读文章、演示视频 | 文档/视频 | P2 |

**明确的非目标（写进 README 顶置）：**
- 不承诺、不销售、不宣传任何"中奖预测"；
- 不做代买、不碰资金、不做任何投注引导；
- 项目结论预设是"检验"而非"预测成功"。

**可量化验收：** 数据完整率 ≥99.9%（期号无断档）；回测覆盖 ≥3000 期；全部模型号级命中率与随机基线差异不显著（p>0.05，经 BH 校正）；API P95 <200ms；D7 末可公网访问 demo。

## 3. 彩票预测是否可行的统计学解释

**机制层：** 双色球由摇奖机物理摇号，每期开奖事件在机制上无状态、无记忆；号码池固定（红 33 选 6、蓝 16 选 1）。大乐透前区 35 选 5、后区 12 选 2。

**概率层（精确计算，公式准入）：**
- 双色球一注中一等奖概率 = 1 / (C(33,6) × 16)。C(33,6) = 33!/(6!27!) = 1,107,568 → **1/17,721,088**。
- 大乐透一注中一等奖概率 = 1 / (C(35,5) × C(12,2)) = 1 / (324,632 × 66) → **1/21,425,712**。
- 随机选 6 个红球，命中个数的期望 = 6 × (6/33) ≈ **1.09 个**；命中 k 个服从超几何分布 P(k) = C(6,k)·C(27,6−k)/C(33,6)。任何"选号法"在不改变开奖分布的前提下，该期望不变，只改变方差（如胆拖/复式是花钱换方差）。

**推断层——常见"规律"为什么是错觉：**
1. **冷热号/遗漏回补**：大数定律描述的是频率随期数收敛，不是"偏差会被偿还"。对下一期没有任何条件概率改变（赌徒谬误）。可用历史数据实测：以"遗漏 >N 期的号在下一期出现率"做单侧检验，预期与 6/33≈18.18% 无显著差异。
2. **和值/区间规律**：对滚动窗口做卡方均匀性检验与游程检验（runs test），历史数据预期全部通过"独立同分布"原假设；任何子序列的"图形规律"在多重建模下都是过拟合。
3. **期望收益**：奖金返奖比例约为销售额的 49%–51%（双色球/大乐透以财政部批复的现行《游戏规则》为准，开发时核对最新文本）。即 **每投 2 元期望回收约 1 元**；选号策略无法改变 EV，蒙特卡洛模拟 100 万期将直接可视化这一收敛。

**结论（工程化表述）：** 在开奖公平的前提下，期与期之间条件互信息 I(X_{t+1}; X_{1..t}) = 0，预测在信息论意义上不可能。项目价值 = 把这句话变成可运行的检验代码与图表。若某模型在回测中显著跑赢随机基线（|z|>3），第一动作是查数据泄漏，其次查多重比较，最后才怀疑摇奖机。

## 4. 可落地项目定位

**一句话定位：** "随机性检验沙箱 + 彩票数据开放分析平台"——一个诚实的、全栈的数据科学作品。

三种产品形态：
1. **Web 平台**：开奖浏览、号码多维分析、模型实验室（在线发起回测并对比随机基线）、娱乐选号（每次输出强制附理论命中率对照）。
2. **Notebook 模板包**：EDA + 假设检验 + 回测解读，面向教学/简历场景。
3. **回测引擎（library）**：`randtest-backtest`，抽象为"任何离散均匀随机事件的策略验证器"，可复用于其他场景。

目标用户：数据科学学习者、招聘方（作品集）、彩票研究爱好者。
变现边界：**只开源、只做技术内容**；不做预测会员、不卖号、不导流购彩（详见第 14 章）。

## 5. 数据来源与字段设计

**数据源（主备双源，开发首日做连通性核验）：**

| 来源 | 内容 | 方式 | 备注 |
|---|---|---|---|
| 中国福彩网 www.cwl.gov.cn | 双色球/七乐彩/福彩3D | HTTP JSON 接口 `.../cwl_admin/front/cwlkj/search/kjxx/findDrawNotice?name=ssq&issueCount=30` | 官方一手源，字段最全（含奖池、各奖等） |
| 竞彩网 webapi.sporttery.cn | 大乐透/排列3/排列5/7星彩 | `.../gateway/lottery/getHistoryPageListV1.qry?gameNo=85&pageSize=30&pageNo=1` | gameNo 映射需实测确认（85≈大乐透） |
| 500.com datachart 页面 | 各彩种历史表 | HTML 表格解析（BeautifulSoup） | 备源/交叉校验源 |
| 聚合数据/极速数据等 API | 开奖查询 | REST | 备源，免费额度有限 |

采集策略：全量历史一次性回溯 + 每日开奖后增量（双色球周二/四/日、大乐透周一/三/六，晚间 22:00 跑批；以官方公告为准）。请求限速 1 req/s、带 UA、失败指数退避、双源 diff 校验。

**数据库设计（PostgreSQL，DDL）：**

```sql
CREATE TABLE lottery_game (
  game_code     TEXT PRIMARY KEY,          -- ssq/dlt/3d/kl8/qxc/p3/p5
  game_name     TEXT NOT NULL,
  org           TEXT NOT NULL CHECK (org IN ('fucai','ticai')),
  schema_json   JSONB NOT NULL,            -- 分区规则，见下方示例
  draw_weekdays INT[],                     -- 常规开奖日 [2,4,7]
  rule_version  TEXT,                      -- 适用的游戏规则版本
  active        BOOLEAN DEFAULT true
);
-- schema_json 示例（双色球）：
-- {"zones":[{"name":"red","pool":33,"pick":6,"ordered":false,"unique":true},
--           {"name":"blue","pool":16,"pick":1,"ordered":false,"unique":true}],
--  "ticket_price": 2.0}

CREATE TABLE draw_result (
  id            BIGSERIAL PRIMARY KEY,
  game_code     TEXT REFERENCES lottery_game(game_code),
  issue_no      TEXT NOT NULL,             -- 期号原样保留 '2026104'
  draw_date     DATE NOT NULL,
  red           INT[] NOT NULL CHECK (array_length(red,1)=6),
  blue          INT[] NOT NULL,
  sales_amount  NUMERIC(18,2),             -- 可为 NULL，不填 0
  pool_amount   NUMERIC(18,2),             -- 奖池滚存
  prize_levels  JSONB,                     -- [{level:1,win_count:7,win_amount:8563916},...]
  source        TEXT NOT NULL,             -- cwl/sporttery/500data
  raw_hash      TEXT NOT NULL,             -- 原始响应 sha256，变更检测
  fetched_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (game_code, issue_no)
);
CREATE INDEX idx_draw_date ON draw_result(game_code, draw_date DESC);

-- ODS 原始层：落全量 JSONB，保证可回溯重放
CREATE TABLE draw_raw_ods (
  id BIGSERIAL PRIMARY KEY, game_code TEXT, issue_no TEXT,
  payload JSONB NOT NULL, source TEXT, http_status INT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- 数据质量日志
CREATE TABLE data_quality_log (
  id BIGSERIAL PRIMARY KEY, run_at TIMESTAMPTZ DEFAULT now(),
  check_name TEXT, issue_no TEXT, severity TEXT,  -- warn/error
  detail JSONB
);
```

核心分析表 `draw_result` 即宽表；派生特征另建 `feature_number_stats`（号×期粒度，物化视图或日批表，见第 7 章）。

## 6. 数据清洗规则

每条规则实现为独立函数，入 DataFrame 出 (df, issues[])，全部结果写 `data_quality_log`：

| # | 规则 | 具体逻辑 | 处置 |
|---|---|---|---|
| R1 | 期号规范化 | 保留原始字符串；对纯数字期号 `lstrip('0')` 前统一补零；同一彩种期号宽度固定，宽度突变=年切换（2026104 vs 26104 类映射表） | 冲突→error |
| R2 | 号码合法性 | 每区个数=pick；值域 [1,pool]；无序区判重 `len(set())==len()`；排列/3D 类允许重复但位数必须=3/5 | 违规→error，阻断入库 |
| R3 | 日期一致性 | `draw_weekdays` 包含 `isodowdraw_date()`；节假日顺延白名单表豁免；日期必须在期号年份之后 | 偏差→warn，人工复核 |
| R4 | 期号连续性 | 按彩种排序后 diff 检测断号；缺号触发定向补采（先查是否休市公告） | 断档→error |
| R5 | 多源一致性 | 主备同源期号 join 比对 red/blue/draw_date，不一致以官方一手源为准并记录 raw_hash | 不一致→error+告警 |
| R6 | 金额字段 | sales/pool 缺失置 NULL（禁止填 0）；负值/超 999 亿判错 | error |
| R7 | 奖等自洽校验 | Σ(win_count×win_amount) 与 sales×返奖比例做量级 sanity check（±1 个数量级内）；固定奖金额必须等于规则表值 | warn |
| R8 | 去重 | `drop_duplicates(subset=[game_code,issue_no], keep='first')`，主源优先排序 | 静默 |
| R9 | 抓取层清洗 | GBK/UTF-8 探测、HTML 表格列错位检测（号码列必须全数字）、空表重试 | retry |
| R10 | 不可变原则 | 清洗产出写 DWD 新分区，不回改 DWD 历史；修正走补丁表 + 视图重放 | 制度 |

## 7. 特征工程清单

**目标定义（先定清楚才谈特征）：**
- 任务 A（号级多标签）：预测下一期每个号码是否出现 → 双色球红区 33 个 0/1 标签。
- 任务 B（聚合回归）：预测下一期和值/区间分布/奇偶比 → 检验"聚合规律"信仰。
- 任务 C（描述统计，产品功能用）：不构成预测主张。

**特征清单（任务 A/B 共用，全部 t-1 截止，point-in-time 铁律）：**

| 类别 | 特征 | 计算 |
|---|---|---|
| 频率 | 号码 i 近 5/10/20/50/100/全部 期出现次数与频率 | rolling count over 号码×期矩阵 |
| 偏差 | 频率−理论期望(6/33) 、z 分数 | 标准化 |
| 遗漏 | 当前遗漏期数、历史最大遗漏、遗漏均值、"遗漏超均值倍数" | 逐号维护 streak |
| 组合(期级) | 和值、跨度(max−min)、AC 值、连号组数、重复号数(vs t−1)、奇偶比、大小比(≥17)、区间比(1-11/12-22/23-33)、除 3/4/5 余数分布 | 期级标量 |
| 共现 | 号对近 N 期共现次数、共现提升度 lift | 33×33 矩阵滑窗 |
| 马尔可夫 | P(号 j 出现 | 号 i 上期出现) | 转移计数矩阵 |
| 日历(对照组) | 星期、月份、节气/农历编码 | **故意加入**，用于向用户演示"伪特征也能进模型" |

**防泄漏三条硬规矩：**
1. 所有 rolling/shift 以 t−1 期为止计算，构造时用 `groupby(号码).shift()` 后向看窗口；
2. 特征矩阵生成逻辑只允许一份实现（feature builder 模块），模型侧禁止自算统计量；
3. 单元测试：随机打乱 t 之后所有未来行，特征输出必须逐位不变（不变性测试）。

## 8. 模型方案对比

| # | 模型 | 原理 | 复杂度 | 预期回测结果 | 项目用途 |
|---|---|---|---|---|---|
| M0 | 均匀随机基线 | 无放回随机选 6 | O(1) | 锚点：号级命中期望 1.09/6 | 对照组，必须存在 |
| M1 | 频率加权采样 | 按近 N 期频率 softmax 加权不放回采样 | 低 | ≈M0 | 量化"追热"策略 |
| M2 | 遗漏回补采样 | 按遗漏值加权（"该出了"） | 低 | ≈M0 | 量化"守冷"策略 |
| M3 | 一阶马尔可夫 | 号对转移概率 → 下一期边际分布采样 | 低 | ≈M0 | 展示"相邻期相关"不存在 |
| M4 | LightGBM 多标签 | 33 个二分类器，号级特征+期级特征 | 中 | 表面上训练集"高"，样本外≈M0 | 过拟合演示主菜 |
| M5 | LSTM/GRU | 号码 0/1 矩阵序列→下一期 33 维输出，BCE loss | 中高 | ≈M0（常更差，方差大） | 博客流行做法的证伪 |
| M6 | Transformer(可选) | 4 层 encoder，位置编码 | 高 | ≈M0 | 容量拉满仍无效→结论强 |
| M7 | 蒙特卡洛 EV 模拟器 | 10⁵~10⁶ 期随机购彩模拟（含奖等分流/平分奖） | 低 | 回报率收敛到返奖比例 | 非预测，证明"必亏结构" |

**训练协议（统一）：** 滑动窗口，train 最近 1000 期 → 预测第 1001 期 → 窗口前移，全历史滚动（约 2000+ 个可测期）；类别不平衡处理统一用类权重而非过采样（避免复制随机性）；超参只在最早 500 期锁定后冻结；正类阈值固定 top-6 排序（与真实"每期 6 个"对齐）。
**判定规则（写死在报告里）：** 样本外号级命中率与 M0 做置换检验（10,000 次），6 个模型 × 2 彩种 × 多窗口全部做 → BH-FDR 校正后仍 p<0.01 且提升>2pp 才算"疑似信号"，然后触发人工审计流程（查泄漏→查上游数据错误→查官方更正公告）。预期结论：无一通过。

## 9. 回测框架

**核心原则：严格 walk-forward，禁止任何 shuffle/split；预测发生在 t 之前，评估发生在 t 之后。**

```
backtest/
├── core/
│   ├── data_source.py     # DrawSource: get_history(game, end_t) -> 截止 t 的全部开奖（内部强制裁剪未来数据）
│   ├── strategy.py        # Strategy 协议：generate(history: pd.DataFrame, ticket_size: int) -> list[Ticket]
│   ├── evaluator.py       # 号级/票级/奖等评估
│   ├── stats.py           # 置换检验、卡方、runs test、BH 校正、bootstrap CI
│   └── engine.py          # 滚动主循环
├── strategies/            # M0–M7 实现
└── reports/               # 输出 JSON + 图
```

```python
class BacktestEngine:
    def __init__(self, source, strategy, game, eval_from_idx, cost_per_ticket=2.0): ...
    def run(self) -> BacktestReport:
        hist_all = self.source.full_history(self.game)
        results = []
        for t in range(self.eval_from_idx, len(hist_all)):
            hist = hist_all.iloc[:t]                  # 只见过去，结构性防泄漏
            tickets = self.strategy.generate(hist, ticket_size=10)
            actual = hist_all.iloc[t]
            results.append(self.evaluator.score(tickets, actual, cost=self.cost_per_ticket))
        return self.aggregate_with_permutation_test(results)
```

**每票评估内容：** 命中红球数 k、是否中蓝、落入账等（严格按现行规则奖级表，浮动奖按当期实际 win_count 平分）、净现金流。
**统计模块（重点，与模型同级公民）：**
1. `permutation_test(model_hits, n_draws=10000)`：把模型每期选号在期之间随机重排，得零分布，算经验 p 值；
2. `chi_square_uniformity(numbers, pool)`：全历史号码均匀性；
3. `runs_test(binary_series)`：奇偶/大小序列独立性；
4. `bh_fdr(p_values, q=0.05)`：多重比较校正。
**产物：** 每模型一份 JSON（逐期记录）+ 汇总报告（p 值表、置信区间、累积收益曲线）。引擎与彩种解耦：新增彩种只写 schema 配置与奖级表。

## 10. 评估指标

| 维度 | 指标 | 定义 | 对照基准 |
|---|---|---|---|
| 号级 | 号码命中率 | 预测 top-6 与实际 6 红交集/6 | 理论随机 = 6/33 ≈ 18.18%（大乐透 5/35≈14.29%） |
| 号级 | 期望命中个数 | Σ 每期命中数均值 | 超几何分布期望（双色球 1.09） |
| 票级 | ≥3 红票占比 / ≥5 红或中一二等奖次数 | 10 票/期 口径 | 随机基线同分布 |
| 资金 | 模拟净回报率 | (Σ奖金−Σ成本)/Σ成本 | 理论 −49%~−51% |
| 资金 | 累积收益最大回撤、破产概率 | MC 模拟分布分位数 | 随机策略分布 |
| 统计 | 置换检验 p 值、Wilson 95% CI、效应量(Cohen's h) | 对随机基线的偏离显著性 | α=0.05（BH 校正后） |
| 分布 | KS 统计量 | 模型命中分布 vs 超几何理论分布 | p>0.05 为"无信号" |
| 系统 | 管道 SLA：采集成功率、断档期数、入库延迟 P95；API 延迟、错误率 | 工程健康度 | ≥99.9% / 0 断档 |

**指标红线（防自欺也防误导别人）：** 禁止用 accuracy 当号级指标（33 选 6 下全预测 0 也有 81.8% accuracy）；禁止展示不带置信区间的"命中率提升"；前端任何指标必须与随机基线值同屏呈现。

## 11. 可视化设计

| 页面 | 图表 | 规格 |
|---|---|---|
| 总览 Dashboard | 最新开奖卡片（红/蓝球徽章）、近 30 期开奖表、奖池走势面积图 | ECharts line + table |
| 号码分析 | ① 频率热力图（33 号 × 近 N 期网格）② 遗漏分布直方图+理论几何分布叠线 ③ 和值分布 vs 正态拟合 ④ 号对共现力导向网络图 | heatmap / bar+line / force |
| 单号追踪 | 选中号码的出现散点 + 滚动频率折线 + 理论期望水平线 | scatter+line，markLine=6/33 |
| 模型实验室 | ① 各模型样本外命中率 vs 随机基线：箱线图/小提琴图叠加（核心图，预期所有箱体盖住基线）② p 值森林图 ③ 各策略累积模拟收益曲线（全部以 −50% 斜率收敛的"清醒图"） | boxplot / custom |
| 蒙特卡洛 | 10 万期随机购彩资金随机走、破产率瀑布、命中 k 红频率 vs 超几何理论柱线 | line overlay |
| 假设检验报告 | 卡方统计量滚动序列 + 95% 临界线带 | line + markArea |

通用要求：每图必须有"理论基准线"图层；色板用色盲安全方案（红蓝球本身改用形状+文字双编码）；移动端图表降采样（LTTB）；所有图支持导出 PNG/CSV。

## 12. 后端 / API 设计

**技术：** FastAPI + SQLAlchemy 2.0(async) + APScheduler(采集/日批特征) + Redis(结果缓存) + PostgreSQL。回测为长任务 → 异步队列（APScheduler 一次性 job + 任务表状态机：pending/running/success/failed）。

**端点（v1，全部 GET 只读除注明）：**

| Method Path | 说明 | 关键参数 → 响应 |
|---|---|---|
| GET /api/v1/games | 彩种元数据 | → [{game_code, name, schema…}] |
| GET /api/v1/draws | 开奖列表 | game, issue_from/to, date_from/to, limit≤200, offset → {total, items[]} |
| GET /api/v1/draws/latest | 最新一期 | game → draw 对象 |
| GET /api/v1/stats/frequency | 频率统计 | game, window ∈ {5,10,20,50,100,all}, zone → [{number, count, freq, z}] |
| GET /api/v1/stats/omission | 遗漏 | game, window → [{number, current, max}] |
| GET /api/v1/stats/tests | 假设检验结果 | game, test ∈ {chi2, runs, ks} → {statistic, p_value, conclusion} |
| POST /api/v1/backtests | 发起回测（异步） | body {game, models[], window, ticket_size, seed} → 202 {task_id} |
| GET /api/v1/backtests/{task_id} | 查询回测 | → {status, summary{p_values, hit_rate_ci}, series[]} |
| GET /api/v1/backtests/leaderboard | 预置回测榜单 | game → 各模型指标表 |
| POST /api/v1/tickets/generate | 娱乐选号 | {game, strategy ∈ {random,freq_hot,omission}, count≤10} → 号码组 + **强制 disclosure 字段** |
| GET /healthz /metrics | 探活 / Prometheus | |

**约定：** 统一响应包 `{code, message, data, request_id}`；错误码 40001 参数错误 / 40401 期号不存在 / 42901 限流 / 50001 内部。限流：网关级 60 req/min/IP，回测发起 5 req/hour/IP（防算力滥用）。`tickets/generate` 响应必须携带 `disclaimer` 字段（服务端拼装，前端不可剥离）。幂等：回测任务以 (params_hash, date) 去重。缓存：stats 类 Redis 600s，draws/latest 120s。

**部署：** Docker Compose 四服务（api、worker、postgres、redis）+ nginx；备份：pg 日 dump 保留 30 天；日志 JSON 结构化 + request_id 链路；监控 Prometheus + 采集断档告警（连续 2 个开奖日无新数据 → 告警）。月度运行成本估算：2C4G 云主机 + 域名，约 ¥60–120/月。

## 13. 前端页面设计

**技术：** Vue 3 + Vite + TypeScript + Element Plus + ECharts 5；Pinia 状态；移动端响应式（断点 768px）。

| 路由 | 页面 | 模块 | 要点 |
|---|---|---|---|
| / | 数据总览 | 最新开奖卡片、奖池走势、近期开奖表 | 首屏即出"本平台不提供中奖预测"横幅（常驻顶部） |
| /draws | 开奖记录 | 筛选器（彩种/年份/期号）、表格、CSV 导出 | 分页 200，虚拟滚动备选 |
| /analysis | 号码分析 | 四 Tab：频率/遗漏/组合特征/共现网络；全局号码选择器联动 | URL query 持久化选择，可分享 |
| /lab | 模型实验室 | 发起回测表单 → 任务进度条 → 结果页（榜单、箱线图、p 值森林、清醒图） | 结论区自动生成一句话解读模板："在 α=0.05 下，所有模型均未显著优于随机选择（p 值：…）" |
| /tickets | 娱乐选号 | 策略选择 + 生成组数 → 号码卡片 | 生成后同屏显示"随机选择也有的理论期望"；分享图水印含免责文本 |
| /report | 统计检验报告 | 静态渲染检验结论 + 方法学附录 | 项目灵魂页，README 置顶链接 |
| /about | 关于与合规 | 免责声明、数据来源、开源协议 | |

交互规范：加载骨架屏；API 错误态给重试按钮与 request_id；空态插画；所有数字带单位与更新时间戳。文案红线：**任何页面禁止出现"预测准确""命中率提升""中奖"字样的营销文案**；"predict"一词仅以 "prediction feasibility test" 形式出现。

## 14. 风险与合规说明

| 风险 | 等级 | 依据/场景 | 缓解措施 |
|---|---|---|---|
| 被认定为变相销售彩票/预测服务 | 高 | 彩票发行销售受财政部《彩票管理条例》约束；网络售彩长期禁止；"卖预测"可能触及诈骗与虚假宣传 | 产品三不：不代买、不收费、不导流购彩；README/页面/接口三层免责；开源可审计 |
| 诱导加大投注（社会责任） | 高 | 用户拿"模型榜单"当投注依据 | 所有策略页强制同屏随机基线与负 EV 结论；娱乐选号限次；不做"每日推荐推送" |
| 爬虫合规 | 中 | 官方站点对抗、robots、频率 | 限速 1req/s、只采公开开奖页、不绕过登录/验证码；备源协议接口；保留 raw 层举证来源 |
| 数据错误导致结论错误 | 中 | 解析错位、官方更正 | 双源 diff + 人工复核队列 + 更正补丁流程（R5/R10） |
| 未成年人接触 | 中 | 公开站点 | 页面底部理性购彩提示（不面向未成年人推广） |
| 算力滥用 | 低 | 回测开放发起 | IP 限流、任务配额、队列上限 |
| 上游接口失效 | 中 | cwl/sporttery 改版 | 备源降级链、失效告警、数据本地全量留存（接口挂了历史分析仍可跑） |

合规声明模板（前端顶置 + API disclaimer 字段 + README）：
> 本项目为数据科学与统计检验的技术演示。彩票开奖为独立随机事件，任何模型均无法提高中奖概率；彩票期望收益为负。本项目不提供、不销售、不支持任何形式的中奖预测或购彩建议。请理性看待彩票。

## 15. 7 天开发计划

| Day | 任务 | 交付物 (DoD) |
|---|---|---|
| D1 | 仓库脚手架（backend/frontend/notebooks monorepo）、Docker Compose、PG 建表迁移；双色球+大乐透双源采集脚本 + 全量历史回灌 + 定时任务 | 库内 ≥15 年两彩种数据；DQC 报告：0 断档、0 非法号 |
| D2 | 清洗管道 R1–R10 单测覆盖；DWD 视图；EDA notebook①（频率/遗漏/和值）与假设检验 notebook（卡方/runs） | 检验初报：p 值表；清洗模块 pytest 全绿 |
| D3 | 特征工程模块 + 号码×期矩阵物化 + **不变性防泄漏测试**；API：games/draws/stats | Postman 用例通过；特征表覆盖 33/35 号全量 |
| D4 | 回测引擎 core（engine/evaluator/permutation/BH）+ M0–M3 | 基线回测报告 JSON：号级命中率落在理论值 ±1σ 内 |
| D5 | M4 LightGBM + M5 LSTM + M7 蒙特卡洛模块；预置回测榜单生成 job | 模型实验室后端可用；10+ 模型×彩种榜单落库 |
| D6 | 前端：/、/draws、/analysis、/lab 四页联调；ECharts 核心图 6 张 | Lighthouse ≥85；移动端适配；图可导出 |
| D7 | /tickets、/report、合规文案；pytest 覆盖率 ≥70%；nginx + HTTPS 部署上线；README + 演示 GIF | 公网 demo 可访问；随机基线同屏校验通过；结果总结文章初稿 |

**裁剪预案：** 任一里程碑延误 → 砍 Pailie/7星彩 只保双色球+大乐透；再延误 → 砍 LSTM 与前端 /tickets，保"数据+回测+报告页"最小闭环（技术结论不依赖前端）。

## 16. 项目亮点总结

1. **诚实的科学**：以工程手段交付一个负结果——用 2000+ 期 walk-forward、置换检验和 FDR 校正量化"预测为什么不可能"，比再写一个营销式"预测系统"稀有得多。
2. **全链路 ML 工程样板**：双源采集→带质量门禁的清洗→point-in-time 特征库→异步回测→API→可视化，每一环都有可验收的 DoD。
3. **防泄漏回测引擎是资产**：结构性裁剪未来数据 + 特征不变性测试 + 统一策略协议，可平移到任何低信噪比随机事件假设检验场景。
4. **统计严谨性内建**：随机基线强制存在、多重比较校正、置信区间同屏展示——方法论素养的直接证明。
5. **合规先行**：三层免责声明、限流防滥用、无资金无导流的"三不"边界，可作为团队内的合规设计案例。
6. **可视化叙事力**："清醒图"（所有策略收益曲线收敛于返奖率斜率）一张图讲完整个统计结论，传播性强。
7. **简历表述**：项目名建议为《随机过程假设检验与策略回测平台（以彩票开奖为对象）》——关键词命中：数据管道、防泄漏、walk-forward、假设检验、FastAPI、全栈交付。

---
*附：本文档中所有组合概率为独立推导计算（C(n,k) 公式），返奖比例与开奖时间以财政部及两彩票机构最新官方规则为准，开发 D1 需核验。*

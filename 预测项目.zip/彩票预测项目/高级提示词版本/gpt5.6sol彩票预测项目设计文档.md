# 彩票预测项目的科学实现方案

> **角色视角：高级数据工程师 / 机器学习工程师**  
> **文档定位：可直接进入开发阶段的技术设计文档**  
> **核心原则：不把随机彩票包装成“可稳定预测”的系统，而是建设一套可验证、可回测、可解释的概率建模与数据分析平台。**

---

## 1. 项目背景

彩票历史数据天然适合做一个完整的数据科学工程项目：

- 数据规模通常不大，但具有明确的时间顺序。
- 每期结果结构固定，适合建立标准化数据仓库。
- 可以系统演示 ETL、特征工程、统计检验、机器学习、时间序列回测、模型监控和可视化。
- 同时也是一个非常容易产生 **数据泄漏、过拟合、幸存者偏差和“热号/冷号”错觉** 的场景。

因此，本项目不应以“AI 找出下一期中奖号码”为工程目标，而应以：

> **历史数据 → 统计检验 → 概率模型 → 多模型比较 → 严格时间序列回测 → 可解释分析**

作为完整技术链路。

彩票运营方通常明确把开奖结果定义为随机事件；例如 Illinois Lottery 明确说明不同期次相互独立，同一种游戏每次投注机会保持相同。Virginia Lottery 也指出每次开奖组合的概率不因之前结果改变。相关随机性要求也被赌博技术标准中的 RNG/随机结果规范覆盖。

---

# 2. 项目真实目标

## 2.1 一级目标

建立一个“彩票历史数据智能分析平台”，而不是承诺中奖的预测器。

平台输出：

1. 历史统计分析
2. 号码频率与遗漏分析
3. 组合结构分析
4. 概率分布估计
5. 多模型概率排序
6. 严格时间序列回测
7. 模型与随机基线比较
8. 可解释性分析
9. 预测稳定性监控

## 2.2 二级目标

回答以下可验证问题：

- 历史开奖是否表现出显著偏离理论分布的现象？
- 某些简单统计特征是否在样本外具有稳定增益？
- ML 模型是否超过随机基线？
- “热号”“冷号”“遗漏”是否真的产生样本外预测价值？
- 不同模型的概率是否校准？
- 如果存在短期偏差，它是否能跨时间窗口持续？

## 2.3 明确不承诺

项目不能将：

- 命中一次
- 回测偶尔盈利
- 某个号码近期频率高
- 某个模型 Top-K 命中率较高

解释成“已经掌握彩票规律”。

**最终判断标准必须是：样本外、滚动回测、多个时间窗口、多个随机种子/基线下仍然稳定。**

---

# 3. 彩票预测是否可行的统计学解释

## 3.1 理论模型

以“从 N 个号码中选 K 个”为例。

如果开奖完全随机且无放回：

\[
P(\text{某一组合})=\frac{1}{\binom{N}{K}}
\]

某个号码单期被选中的边际概率：

\[
P(i)=\frac{K}{N}
\]

因此历史上出现：

- 某号码连续出现
- 某号码长期没出现
- 某几个号码一起出现
- 奇偶比发生变化

都不自动意味着下一期概率发生变化。

## 3.2 独立性

设第 t 期结果为 \(Y_t\)。

理想情况下：

\[
P(Y_{t+1}|Y_t,Y_{t-1},...)=P(Y_{t+1})
\]

也就是说过去开奖结果不能改变下一期理论概率。

官方彩票机构也反复强调：此前结果不会让某个号码“更该出现”，也不会因为连续未中奖而增加下一次中奖概率。

## 3.3 为什么机器学习仍然值得做？

因为工程项目可以验证三个不同假设：

### H0：完全随机

历史数据不存在可利用的稳定信号。

### H1：存在统计偏差

例如：

- 设备偏差
- 数据采集错误
- 游戏规则变化
- 样本分布异常

### H2：存在可利用的时间依赖

这是最强假设，也是最难成立的。

项目应该通过统计检验和样本外回测区分 H0/H1/H2，而不是预先假设“AI 一定可以预测”。

## 3.4 最重要的结论

> **彩票预测项目最科学的结果，可能不是找到一个强预测模型，而是证明复杂模型并没有稳定超过随机基线。**

这本身就是有效的机器学习实验结论。

---

# 4. 可落地项目定位

项目名称建议：

**LotteryLab — 彩票概率建模与回测平台**

定位：

> 面向彩票历史数据的统计分析、概率建模、机器学习实验和严格回测平台。

系统分成 5 层：

```text
数据源
  ↓
ETL / 数据质量层
  ↓
Feature Store
  ↓
模型实验层
  ↓
回测 + API + Web Dashboard
```

推荐 MVP：

```text
Python
├── pandas / polars
├── numpy
├── scipy
├── scikit-learn
├── lightgbm（可选）
├── FastAPI
├── PostgreSQL
└── React / Next.js
```

如果希望降低开发难度：

```text
Python + SQLite/PostgreSQL + FastAPI + Streamlit
```

即可完成第一版。

---

# 5. 数据来源与字段设计

## 5.1 数据来源优先级

### A. 官方开奖数据

优先级最高：

- 官方彩票机构
- 官方历史开奖页面
- 官方 CSV / API
- 官方开奖公告

### B. 第三方数据源

仅作为补充：

- 彩票历史数据库
- 数据聚合网站
- 开源数据集

第三方数据必须进行交叉校验。

### C. 本地导入

支持：

```text
CSV
Excel
JSON
```

方便后期替换数据源。

---

## 5.2 原始表 `draw_results`

| 字段 | 类型 | 说明 |
|---|---|---|
| id | BIGINT | 主键 |
| lottery_code | VARCHAR | 彩票类型 |
| issue | VARCHAR | 期号 |
| draw_date | DATE | 开奖日期 |
| n1 | SMALLINT | 第1号码 |
| n2 | SMALLINT | 第2号码 |
| n3 | SMALLINT | 第3号码 |
| n4 | SMALLINT | 第4号码 |
| n5 | SMALLINT | 第5号码 |
| n6 | SMALLINT | 第6号码 |
| bonus | SMALLINT | 特别号 |
| source | VARCHAR | 数据来源 |
| source_hash | VARCHAR | 原始记录哈希 |
| created_at | TIMESTAMP | 入库时间 |

不同彩票可以扩展为：

```text
numbers JSONB
bonus_numbers JSONB
```

---

## 5.3 标准化表 `draw_numbers`

建议采用长表：

| 字段 | 类型 |
|---|---|
| draw_id | BIGINT |
| position | SMALLINT |
| number | SMALLINT |
| is_bonus | BOOLEAN |

例如：

```text
draw_id | position | number | is_bonus
10001   | 1        | 03     | false
10001   | 2        | 11     | false
10001   | 3        | 18     | false
```

这样方便：

- 频率统计
- SQL 聚合
- 特征计算
- 模型训练

---

## 5.4 模型预测表 `predictions`

| 字段 | 类型 |
|---|---|
| prediction_id | BIGINT |
| model_id | VARCHAR |
| draw_date | DATE |
| number | INT |
| probability | DOUBLE |
| rank | INT |
| score | DOUBLE |
| created_at | TIMESTAMP |

---

## 5.5 回测表 `backtest_results`

| 字段 | 类型 |
|---|---|
| run_id | VARCHAR |
| model_id | VARCHAR |
| test_start | DATE |
| test_end | DATE |
| top_k | INT |
| hit_count | INT |
| precision | DOUBLE |
| recall | DOUBLE |
| log_loss | DOUBLE |
| brier_score | DOUBLE |
| baseline_delta | DOUBLE |

---

# 6. 数据清洗规则

## 6.1 基础检查

每期必须：

```text
issue 不为空
draw_date 不为空
号码数量符合规则
号码在合法范围内
```

## 6.2 重复检查

唯一键：

```text
lottery_code + issue
```

发现重复：

```text
保留官方源
记录 duplicate_count
禁止静默覆盖
```

## 6.3 排序检查

对于组合型彩票：

```text
n1 < n2 < n3 < ...
```

如果原始数据顺序没有语义，统一排序。

## 6.4 号码范围

例如：

```python
assert 1 <= number <= MAX_NUMBER
```

特别号使用独立范围。

## 6.5 日期检查

检测：

- 日期倒序
- 同期多个日期
- 日期缺口
- 游戏规则变更

## 6.6 规则版本

必须建立：

```text
game_rules
```

例如：

```text
lottery_code
effective_date
main_number_count
main_number_max
bonus_number_count
bonus_number_max
```

原因：

> 彩票规则发生变化时，不能直接把不同规则的数据混成一个训练集。

## 6.7 数据质量评分

每次 ETL 生成：

```text
completeness
uniqueness
validity
consistency
timeliness
```

最终：

```text
data_quality_score = weighted_mean(...)
```

低于阈值禁止训练。

---

# 7. 特征工程清单

## 7.1 基础统计特征

每期：

```text
sum
mean
median
std
min
max
range
```

例如：

\[
range=max-min
\]

---

## 7.2 奇偶特征

```text
odd_count
even_count
odd_even_ratio
```

---

## 7.3 大小特征

根据游戏号码范围定义：

```text
small_count
large_count
small_large_ratio
```

---

## 7.4 分区特征

例如将号码空间划分：

```text
1~10
11~20
21~30
31~40
...
```

生成：

```text
zone_1_count
zone_2_count
zone_3_count
```

---

## 7.5 连号特征

```text
consecutive_pairs
max_consecutive_length
has_consecutive
```

---

## 7.6 和值特征

```text
sum
rolling_mean_sum_5
rolling_mean_sum_10
rolling_std_sum_20
```

注意：

这些只能用于研究历史结构，不能直接解释为未来号码概率变化。

---

## 7.7 号码频率

对每个号码计算：

```text
freq_5
freq_10
freq_20
freq_50
freq_100
```

必须全部使用过去数据：

```python
shift(1).rolling(window)
```

禁止：

```python
rolling(window)
```

直接参与预测，否则会泄漏当前期。

---

## 7.8 遗漏特征

```text
days_since_last_seen
draws_since_last_seen
max_gap
mean_gap
```

注意：

“遗漏越久越容易出现”属于典型赌徒谬误假设。

项目应该把它当成一个待验证特征，而不是事实。

---

## 7.9 共现特征

计算：

```text
pair_frequency
triple_frequency
conditional_frequency
```

例如：

\[
P(B|A)
\]

但必须使用训练窗口计算。

---

## 7.10 时间特征

```text
weekday
month
quarter
year
draw_interval
```

时间特征需要特别谨慎。

如果理论上开奖机制与时间无关，模型很可能只是学习随机噪声。

---

# 8. 模型方案对比

## 8.1 Baseline 0：理论随机模型

必须存在。

输出：

```text
每个号码理论概率
```

它是所有模型的第一基准。

---

## 8.2 Baseline 1：历史频率模型

根据过去 N 期：

```text
P(number) = frequency / total_draws
```

优点：

- 简单
- 可解释
- 作为强基线

缺点：

- 对随机波动敏感

---

## 8.3 Baseline 2：滑动窗口模型

例如：

```text
last 20
last 50
last 100
```

分别计算号码概率。

---

## 8.4 Logistic Regression

适合：

```text
号码是否下一期出现
```

输出：

\[
P(y_i=1|X)
\]

优点：

- 可解释
- 训练快
- 适合建立第一版监督学习基线

---

## 8.5 Random Forest

优点：

- 非线性
- 对特征尺度不敏感
- 容易分析 feature importance

缺点：

- 小样本容易产生伪规律
- 概率校准可能较差

---

## 8.6 LightGBM

适合：

```text
号码概率排序
```

推荐作为主力实验模型之一。

但不要默认 LightGBM 一定比简单模型好。

---

## 8.7 XGBoost

用于和 LightGBM 对比。

重点观察：

```text
样本外 log loss
Brier score
Top-K hit rate
```

而不是只看训练集 accuracy。

---

## 8.8 LSTM / Transformer

可以作为实验模型，但不是 MVP 必需。

原因：

- 数据量通常不足
- 序列本身可能没有有效信息
- 参数量大
- 很容易过拟合

因此推荐：

```text
Phase 1：传统统计 + Tree Model
Phase 2：序列模型
```

---

## 8.9 模型推荐矩阵

| 模型 | 可解释性 | 复杂度 | 推荐 |
|---|---:|---:|---:|
| 理论随机 | ★★★★★ | ★ | 必须 |
| 历史频率 | ★★★★★ | ★ | 必须 |
| 滑动窗口 | ★★★★★ | ★ | 必须 |
| Logistic | ★★★★ | ★★ | 推荐 |
| Random Forest | ★★★ | ★★★ | 推荐 |
| LightGBM | ★★★ | ★★★ | 主力 |
| XGBoost | ★★★ | ★★★ | 对比 |
| LSTM | ★★ | ★★★★ | 实验 |
| Transformer | ★★ | ★★★★★ | 后期 |

---

# 9. 回测框架

这是整个项目最重要的模块。

## 9.1 禁止随机 train/test split

不能：

```python
train_test_split(data, random_state=42)
```

因为彩票数据有时间顺序。

必须：

```text
过去 → 训练
未来 → 测试
```

---

## 9.2 Walk-forward Backtest

例如：

```text
Train：1~1000
Test ：1001

Train：1~1001
Test ：1002

Train：1~1002
Test ：1003
```

持续滚动。

---

## 9.3 Rolling Window

另一种：

```text
Train：801~1000
Test ：1001

Train：802~1001
Test ：1002
```

用于研究“近期数据是否更有价值”。

---

## 9.4 时间切分

推荐：

```text
Train      70%
Validation 15%
Test       15%
```

但必须按时间切分，而不是随机抽样。

---

## 9.5 严格防止数据泄漏

预测第 t 期：

```text
features[t] 只能来自 <= t-1 的数据
label[t]     = 第 t 期结果
```

推荐统一写：

```python
feature_df = raw_df.shift(1)
```

然后生成 rolling features。

---

## 9.6 回测伪代码

```python
for test_idx in range(min_train, len(data)):

    train = data.iloc[:test_idx]
    test = data.iloc[test_idx:test_idx+1]

    model.fit(
        train.X,
        train.y
    )

    prob = model.predict_proba(test.X)

    metrics = evaluate(
        prob,
        test.y
    )

    results.append(metrics)
```

---

## 9.7 必须设置随机基线

例如：

```text
Random baseline
Frequency baseline
Uniform baseline
Model A
Model B
Ensemble
```

最终比较：

```text
Model - Random
Model - Frequency
```

而不是只展示模型自己的命中率。

---

# 10. 评估指标

## 10.1 Accuracy

不推荐作为核心指标。

原因：

多标签彩票问题中 accuracy 很容易产生误导。

---

## 10.2 Top-K Hit Rate

例如：

```text
Top 5
Top 10
Top 20
```

计算：

\[
HitRate=\frac{\text{命中的测试期数}}{\text{测试期总数}}
\]

---

## 10.3 Precision@K

\[
Precision@K =
\frac{预测集合与真实集合交集数量}{K}
\]

---

## 10.4 Recall@K

\[
Recall@K =
\frac{命中号码数}{真实号码总数}
\]

---

## 10.5 Log Loss

对于概率模型非常重要：

\[
LogLoss=-\frac{1}{N}\sum[y\log(p)+(1-y)\log(1-p)]
\]

越低越好。

---

## 10.6 Brier Score

衡量概率预测质量：

\[
BS=\frac{1}{N}\sum(p-y)^2
\]

越低越好。

---

## 10.7 Calibration

绘制：

```text
Predicted Probability
vs
Observed Frequency
```

如果模型预测：

```text
0.10
```

实际长期出现率也接近：

```text
0.10
```

说明概率校准较好。

---

## 10.8 Baseline Lift

定义：

\[
Lift=
\frac{ModelMetric}{BaselineMetric}
\]

重点观察：

```text
长期 lift
rolling lift
不同年份 lift
```

---

## 10.9 稳定性

模型不能只在一个时间窗口表现好。

必须检查：

```text
monthly performance
quarterly performance
yearly performance
```

如果：

```text
训练集很好
验证集很好
测试集崩溃
```

基本就是过拟合。

---

# 11. 可视化设计

## 11.1 首页 Dashboard

显示：

```text
数据总期数
最新期号
模型数量
最近回测窗口
最佳模型
随机基线
模型 Lift
```

---

## 11.2 号码频率图

```text
Number → Frequency
```

支持：

```text
Top 10
Bottom 10
全部号码
```

---

## 11.3 遗漏走势图

横轴：

```text
期号
```

纵轴：

```text
遗漏次数
```

---

## 11.4 和值趋势

显示：

```text
Actual Sum
Rolling Mean
Rolling Std
```

---

## 11.5 奇偶分布

显示：

```text
0:6
1:5
2:4
3:3
4:2
5:1
6:0
```

用于结构统计。

---

## 11.6 模型对比

推荐：

```text
Random
Frequency
Logistic
RF
LightGBM
XGBoost
```

指标：

```text
LogLoss
Brier
Hit@K
Calibration
```

---

## 11.7 回测收益模拟

如果项目需要研究投注策略：

必须单独标记：

```text
simulation only
```

并提供：

```text
累计投入
累计奖金
ROI
最大回撤
胜率
```

不得将模拟收益展示成实际盈利承诺。

---

# 12. 后端/API设计

推荐：

```text
FastAPI
```

## 12.1 API

### 获取最新开奖

```http
GET /api/v1/draws/latest
```

### 历史开奖

```http
GET /api/v1/draws
```

参数：

```text
page
page_size
start_date
end_date
```

### 号码统计

```http
GET /api/v1/statistics/numbers
```

### 特征分析

```http
GET /api/v1/statistics/features
```

### 模型列表

```http
GET /api/v1/models
```

### 模型预测

```http
POST /api/v1/predictions
```

请求：

```json
{
  "lottery_code": "xxx",
  "model": "lightgbm",
  "top_k": 10
}
```

### 回测

```http
POST /api/v1/backtests
```

### 回测结果

```http
GET /api/v1/backtests/{run_id}
```

---

# 13. 前端页面设计

## 页面 1：Dashboard

布局：

```text
┌──────────────────────────────┐
│ LotteryLab                   │
├──────────────────────────────┤
│ 数据量 │ 模型 │ 最新期 │ 状态 │
├──────────────────────────────┤
│ 号码频率图                   │
├──────────────────────────────┤
│ 遗漏趋势                     │
├──────────────────────────────┤
│ 模型回测                     │
└──────────────────────────────┘
```

---

## 页面 2：历史开奖

功能：

```text
分页
筛选
搜索期号
日期过滤
导出 CSV
```

---

## 页面 3：统计分析

模块：

```text
号码频率
遗漏
奇偶
大小
分区
和值
连号
共现
```

---

## 页面 4：模型中心

显示：

```text
模型名称
训练时间
训练窗口
特征版本
模型版本
验证指标
测试指标
```

---

## 页面 5：预测实验

输入：

```text
彩票类型
模型
Top-K
训练窗口
```

输出：

```text
号码
概率
Rank
模型分数
历史频率
```

必须显示：

> “模型排序结果，不代表实际中奖概率被改变。”

---

## 页面 6：回测中心

核心：

```text
模型 vs 随机基线
```

支持：

```text
时间范围
模型
Top-K
窗口
指标
```

---

## 页面 7：模型解释

推荐：

```text
Feature Importance
SHAP
Calibration Curve
Prediction Distribution
```

---

# 14. 风险与合规说明

## 14.1 最大风险：误导性预测

禁止使用：

```text
必中
稳赚
100%准确
AI破解彩票
内部规律
保证中奖
```

---

## 14.2 模型风险

重点防范：

### 过拟合

模型学习历史噪声。

### 数据泄漏

未来信息进入历史特征。

### p-hacking

大量尝试特征后只展示最好的结果。

### Multiple Testing

尝试数百种策略后，某个策略偶然表现优秀。

### Gambler's Fallacy

错误认为：

```text
某号码很久没出现
→ 下一期更容易出现
```

---

## 14.3 产品风险

如果平台涉及真实投注或商业化：

必须根据目标地区法律法规评估：

```text
彩票销售
赌博服务
预测服务
广告
会员收费
数据授权
用户年龄
支付
```

本项目第一版建议只做：

> 数据分析 + 科研实验 + 回测模拟

不接入真实投注。

---

# 15. 7天开发计划

## Day 1：数据层

完成：

```text
项目初始化
数据库
数据模型
CSV 导入
官方数据采集器
数据清洗
```

验收：

```text
至少 1000 期历史数据正确入库
```

---

## Day 2：统计分析

完成：

```text
号码频率
遗漏
奇偶
大小
和值
连号
分区
```

输出：

```text
statistics.py
```

---

## Day 3：Feature Store

完成：

```text
rolling frequency
gap
sum
odd/even
zone
pair
trend
```

重点：

```text
100% 时间序列防泄漏
```

---

## Day 4：模型

实现：

```text
Random baseline
Frequency
Logistic
RandomForest
LightGBM
```

统一接口：

```python
model.fit(X_train, y_train)
model.predict_proba(X_test)
```

---

## Day 5：回测

完成：

```text
Walk-forward
Rolling window
Top-K
LogLoss
Brier
Calibration
Baseline comparison
```

这是整个项目的核心验收日。

---

## Day 6：API + Dashboard

完成：

```text
FastAPI
Swagger
Dashboard
历史开奖
统计分析
模型结果
回测
```

---

## Day 7：稳定性与上线

完成：

```text
异常监控
日志
模型版本
数据版本
Docker
README
定时任务
```

最终运行：

```text
ETL
 ↓
Feature
 ↓
Train
 ↓
Backtest
 ↓
Report
```

---

# 16. 项目亮点总结

## 亮点 1：不是“玄学预测”

整个项目采用：

```text
统计学
+
概率论
+
机器学习
+
时间序列回测
```

---

## 亮点 2：随机基线优先

任何 ML 模型必须回答：

> “你比随机模型强多少？”

而不是：

> “你命中了多少次？”

---

## 亮点 3：严格防止数据泄漏

所有预测特征遵守：

```text
Prediction(t)
← Data(<t)
```

---

## 亮点 4：模型必须样本外验证

采用：

```text
Walk-forward
Rolling Window
Out-of-Sample
```

而不是随机拆分。

---

## 亮点 5：概率而非单纯号码

系统核心输出：

```text
P(number | history)
```

然后再进行：

```text
ranking
top-k
calibration
backtest
```

---

## 亮点 6：可解释

每一个模型结果都可以追溯：

```text
数据版本
→ 特征版本
→ 模型版本
→ 参数
→ 回测窗口
→ 指标
```

---

## 亮点 7：可以持续实验

后续可以增加：

```text
Bayesian Model
HMM
XGBoost
LightGBM
LSTM
Transformer
Ensemble
Monte Carlo
Bootstrap
Permutation Test
```

但新模型必须通过统一回测框架与随机基线比较。

---

# 推荐项目目录

```text
lotterylab/
├── data/
│   ├── raw/
│   ├── processed/
│   └── features/
│
├── src/
│   ├── ingestion/
│   ├── cleaning/
│   ├── features/
│   ├── models/
│   ├── backtest/
│   ├── metrics/
│   └── visualization/
│
├── api/
│   ├── routes/
│   ├── schemas/
│   └── services/
│
├── frontend/
│
├── tests/
│
├── configs/
│
├── notebooks/
│
├── scripts/
│
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

# 最终技术路线

```text
              ┌───────────────┐
              │ 官方开奖数据   │
              └───────┬───────┘
                      ↓
              ┌───────────────┐
              │ ETL / 清洗    │
              └───────┬───────┘
                      ↓
              ┌───────────────┐
              │ PostgreSQL    │
              └───────┬───────┘
                      ↓
              ┌───────────────┐
              │ Feature Store │
              └───────┬───────┘
                      ↓
       ┌──────────────┼──────────────┐
       ↓              ↓              ↓
    Random       Frequency       ML Models
       │              │              │
       └──────────────┼──────────────┘
                      ↓
              ┌───────────────┐
              │ Walk Forward  │
              │ Backtest      │
              └───────┬───────┘
                      ↓
              ┌───────────────┐
              │ Metrics       │
              │ Calibration   │
              │ Stability     │
              └───────┬───────┘
                      ↓
              ┌───────────────┐
              │ FastAPI       │
              └───────┬───────┘
                      ↓
              ┌───────────────┐
              │ Web Dashboard │
              └───────────────┘
```

# MVP 最终验收标准

第一版上线前必须满足：

- [ ] 历史数据可重复导入
- [ ] 数据质量检查可自动执行
- [ ] 彩票规则版本化
- [ ] 特征生成无未来数据泄漏
- [ ] 至少 3 个 baseline/model
- [ ] Walk-forward 回测可重复运行
- [ ] LogLoss / Brier / Top-K / Calibration 可计算
- [ ] 模型与随机基线自动比较
- [ ] 每次实验有唯一 run_id
- [ ] 模型版本可追溯
- [ ] 前端可以查看历史、统计、预测实验、回测
- [ ] 所有“预测”结果明确标记为概率模型实验结果
- [ ] 不把历史统计波动包装为确定性规律

# 一句话结论

**这个项目真正值得做的地方，不是制造一个“神奇选号器”，而是把一个看似可以预测的问题，严格转化成一个可重复、可验证、可回测的概率建模工程。**

如果最终实验发现复杂模型长期无法稳定超过随机基线，这不是项目失败，而是一个具有统计学意义的结论：**在当前数据和实验设计下，没有证据表明历史开奖数据包含足以产生稳定样本外预测优势的信息。**
